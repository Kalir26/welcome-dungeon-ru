/* AdventureScene::NextDay/update/Attack/SelectDayBonus/RandBonusCard.
 * This minigame uses two HP per collection member, not dungeon character stats.
 * All random tables are extracted from the original ELF. */
(function(scope){
'use strict';
class NativeAdventureRules{
 constructor(rules,id,random=Math.random){this.rules=rules;this.d=rules.d.nativeAdventure;this.id=id;this.trip=rules.d.TRIPS[id-1];if(!this.trip)throw Error('Invalid native adventure');this.random=random;this.party=rules.d.COLLECTIONS[id-1].slice(1,6).filter(Boolean).map(id=>({id,element:rules.character(id).element,hp:2}));this.events=[];this.day=0;this.mode=0;this.heroCount=0;this.heroes=[];this.enemy=null;this.metMagician=false;this.canSwitch=true;this.gold=0;this.extraGold=0;this.gem=0;this.traps=0;this.monster=0;this.points=0;this.elapsed=0;this.ended=false;this.nextDay();}
 int(n){return Math.floor(this.random()*n);}
 emit(type,fields={}){this.events.push({type,...fields});}
 drain(){return this.events.splice(0);}
 nextDay(){this.mode=0;this.day++;if(this.day>this.trip[0])return this.finish();this.emit('dayIntro',{day:this.day});}
 startDay(){if(this.ended)return;this.mode=1;this.heroCount=0;this.heroes=[];this.canSwitch=true;}
 swap(index){if(!this.canSwitch||index<1||index>=this.party.length||![1,2,3].includes(this.mode))return false;[this.party[0],this.party[index]]=[this.party[index],this.party[0]];this.emit('swap',{index});return true;}
 hero(){const name=this.d.heroNames[this.int(this.d.heroNames.length)],character=this.rules.d.characters.find(c=>c.id>=2000&&c.id<3000&&c.name===name);if(!character)throw Error('Missing original adventure hero '+name);this.enemy={type:'hero',name,id:character.id,element:character.element,x:-960,y:this.d.heroY};this.heroes.push((Math.trunc((character.id-2000)/100)*10)+character.id%10);this.heroCount++;this.emit('enemy',{enemy:this.enemy});}
 attack(){const front=this.party[0],enemy=this.enemy,m=front.element,h=enemy.element;let damage=0;if(m===h)damage=1;else if((m===0&&h!==1)||(m===1&&h!==2)||(m===2&&h!==0))damage=2;front.hp-=damage;enemy.dead=true;this.attackDelay=1;this.emit('attack',{enemy,front,damage});if(front.hp<1){this.party.shift();this.emit('memberDied',{front});if(!this.party.length)this.finish();}this.canSwitch=true;}
 endDay(){if(this.ended)return;this.mode=0;this.canSwitch=false;this.dayBonusAvailable=true;this.emit('dayBonus',{heroes:this.heroes.slice()});}
 selectDayBonus(index){if(!this.dayBonusAvailable||this.mode!==0||this.dayBonusSelected||!Number.isInteger(index)||index<0||index>2)return null;const amount=(this.int(19)+2)*100;this.gold+=amount;this.dayBonusSelected=true;this.emit('dayGold',{index,amount});return amount;}
 confirmDay(){if(!this.dayBonusSelected)return false;this.dayBonusAvailable=false;this.dayBonusSelected=false;this.nextDay();return true;}
 chooseMagician(accept,wallet){if(this.mode!==4||this.magicianDecided)return false;this.magicianDecided=true;const yes=accept&&wallet>=this.trip[2];this.extraGold=yes?-this.trip[2]:1000;if(yes){this.emit('bonusCards');}else this.emit('magicianGift',{amount:1000});return yes;}
 bonusType(){const value=this.int(1000),column=this.trip[1]-1;let sum=0;for(let i=0;i<15;i++){sum+=this.d.bonusWeights[i][column];if(value<sum)return i;}return 0;}
 selectBonus(index){if(this.mode!==4||this.bonusSelected||!Number.isInteger(index)||index<0||index>=12)return null;this.bonusSelected=true;const type=this.bonusType();if(type<12)this.monster=this.d.bonusMonsterIDs[type];else if(type===12)this.traps=1;else if(type===13)this.gem=1;this.emit('bonusChosen',{index,bonusType:type});return type;}
 endMagician(){this.enemy=null;this.emit('removeEnemy');this.endDay();}
 finish(){if(this.ended)return;this.mode=5;this.ended=true;const win=this.party.length>0;this.points=win?this.d.winPoints[this.trip[1]-1]:50;this.emit('result',{win,gold:this.gold+this.extraGold,gem:this.gem,traps:this.traps,monster:this.monster,points:this.points});}
 update(dt,speed=false){if(!Number.isFinite(dt)||dt<0)throw Error('Invalid adventure time');this.elapsed+=Math.min(dt,1);while(this.elapsed>=1/60){this.elapsed-=1/60;this.frame(speed);}}
 frame(speed){if(this.ended||![1,2,3].includes(this.mode))return;const step=speed?2:1;this.emit('scroll',{back:step,front:this.d.parallaxStep*step});
  if(this.attackDelay>0){this.attackDelay-=1/60;if(this.attackDelay<=0){this.enemy=null;this.emit('removeEnemy');}return;}
  if(!this.enemy){this.canSwitch=true;if(this.heroCount<3){this.hero();return;}const chance=this.int(100);if(!this.metMagician){this.metMagician=true;this.mode=3;this.enemy={type:'magician',x:0,y:300};this.emit('enemy',{enemy:this.enemy});}else if(chance<30&&this.day!==this.trip[0]){this.mode=2;this.enemy={type:'castle',x:0,y:300};this.emit('enemy',{enemy:this.enemy});}else this.endDay();return;}
  const enemy=this.enemy;if(enemy.type==='hero'){if(enemy.x>=480+this.d.attackOffset){this.attack();return;}if(enemy.x>=480)this.canSwitch=false;enemy.x+=(this.d.heroStep+this.day*3)*step;}
  else if(enemy.type==='magician'){if(enemy.x>=480-this.d.attackOffset){this.canSwitch=false;this.mode=4;this.emit('magician');return;}enemy.x+=this.d.parallaxStep*step;}
  else{if(enemy.x>=960){this.enemy=null;this.emit('removeEnemy');this.mode=1;this.endDay();return;}if(enemy.x>=480+this.d.attackOffset&&!enemy.raided){enemy.raided=true;this.party[0].hp=2;this.emit('castleHeal');}else if(enemy.x>=480)this.canSwitch=false;enemy.x+=this.d.parallaxStep*step;}
 }
}
scope.NativeAdventureRules=NativeAdventureRules;if(typeof module==='object'&&module.exports)module.exports={NativeAdventureRules};
})(typeof window==='object'?window:globalThis);
