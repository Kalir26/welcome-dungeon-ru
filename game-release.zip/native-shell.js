/* StageReadyMenuUI and StageScene tutorial callbacks, native 0x21abc0,
 * 0x21d4a0. Client tutorial progress is saved only at the original milestones. */
(function(){
'use strict';const P=window.NativePort;
P.isGotchaTutorial=()=>[2,6,8].includes(P.profile.client.tutorial);
P.isPartyTutorial=()=>[3,7,9].includes(P.profile.client.tutorial);
P.removeStageHand=function(){P.stage.tutorialHand?.removeFromParent(true);P.stage.tutorialHand=null;};
P.stageHand=async function(x,y){P.removeStageHand();const hand=P.stage.tutorialHand=await P.readScene('ccb/CD_UI_hand_cursor.ccbi');hand.setPosition(x,y);P.stage.host.addChild(hand,105,19937);};
P.stageMenuAllowed=function(tag){if(P.modal)return false;if(P.isGotchaTutorial())return tag===2;if(P.isPartyTutorial())return tag===1;return P.profile.client.tutorial>=5&&P.stage.mode===0;};
P.stageMenuButton=async function(tag){
 if(P.stage.menuBusy||!P.stageMenuAllowed(tag))return;const s=P.stage;s.menuBusy=true;P.removeStageHand();
 try{P.audio.play('enchant_select.mp3').catch(P.fail);if(tag===1)await P.openInventory();else if(tag===2)await P.openGotcha();else if(tag===3)await P.notice(P.language==='ru'?'Сетевые битвы Владык недоступны в автономной версии.':'Online Devil-vs-Devil battles are unavailable offline.');else if(tag===4)await P.openQuests();}finally{s.menuBusy=false;}
};
P.stageMenuActions=function(){
 if(!P.stage.ready||P.stage.index===0)return [];
 const actions=[[1,'Ящик монстров'],[2,'Призыв монстров'],[3,'Битвы Владык'],[4,'Достижения']].filter(([tag])=>P.stageMenuAllowed(tag)).map(([tag,label])=>({label,run:()=>P.stageMenuButton(tag)}));
 if(P.profile.client.tutorial>=10&&P.stage.mode===0)actions.push({label:'Меню игры',run:()=>P.openEntertain(5)},{label:'Карта подземелий',run:()=>P.showWorldMap()});
 return actions;
};
P.addReadyMenu=async function(){
 const s=P.stage;if(s.index===0)return;
 const root=s.readyMenu=await P.readScene('ccb/stage_ready_menu_ui.ccbi');root.setPosition(960,0);s.ready.addChild(root,100,0);
 // The shipped APK's renewed right-hand controls use a 100px stack below
 // MENU (native v98 reference: evidence/extended/v98/ui/box_closed_correct).
 // The legacy CCBI positions otherwise put summon underneath the new MENU.
 const buttons=root.m_menuMVM.getParent();buttons.getChildByTag(2).setPositionY(-225);buttons.getChildByTag(1).setPositionY(-325);
 // StageReadyMenuUI::onNodeLoaded, 0x21a960: keep the hit target, but make
 // its static portal artwork transparent beneath portal_eyes' animation.
 root.m_menuMVM.getNormalImage().setOpacity(0);
 root.m_menuQuest.setVisible(true);
 const eyes=await P.readScene('ccb/portal_eyes.ccbi');eyes.setPosition(-235,-168);root.addChild(eyes,100);
};
P.controllers.set('StageReadyMenuUI',{onMenuCallback:async function(sender){await P.stageMenuButton(sender.getTag());}});
P.initializeNormalStage=async function(){
 const s=P.stage;await P.addReadyMenu();await P.nativeStageHUD();await P.reloadQuest(s.lever);const t=P.profile.client.tutorial;
 if(t===2){s.mode=10;P.after(s.host,.3,()=>P.talk(s.host,2,7).catch(P.fail));}
 else if(t===3){s.mode=10;P.after(s.host,.3,()=>P.talk(s.host,2,10).catch(P.fail));}
 else if(t===4){s.mode=10;P.after(s.host,.3,()=>P.talk(s.host,2,11).catch(P.fail));}
 else if(t===6||t===8)await P.handleTutorialMessage('Tutorial_Gotcha02');
 else if(t===7||t===9)await P.handleTutorialMessage('Tutorial_SelectMonster02');
 else{s.mode=0;P.status('Подземелье '+s.index);P.stageActions();await P.maybeDailyReward?.();}
};
P.nativeStageHUD=async function(){
 const s=P.stage;
 await Promise.all(['CD_coin_01.png','CD_coin_00.png'].map(P.image));
 // Empty native sprites are containers; HTML5's empty Sprite draws a white
 // rectangle when given a size. A plain Node preserves the native behaviour.
 const money=s.money=cc.Node.create();money.setPosition(105,40);money.setContentSize(210,80);
 for(const [i,name]of ['CD_coin_01.png','CD_coin_00.png'].entries()){const icon=cc.Sprite.create(name);icon.setPosition(0,i===0?20:-20);money.addChild(icon);const label=cc.LabelTTF.create('',P.text('local_font'),14);label.setPosition(icon.getPosition());money.addChild(label,1,i);}
 const mini=s.minimap=cc.Sprite.create();mini.setPosition(302,187);s.host.addChild(mini,100);
 const layout=P.mapIndex['00_dungeon_'+String(s.index).padStart(2,'0')],slots=layout.objects.filter(o=>/^Slot_/.test(o.name)).sort((a,b)=>Number(a.name.slice(5))-Number(b.name.slice(5)));
 const frames=['CD_minimap_door.png',...slots.slice(0,-1).map(o=>o.type==='Trap'?'CD_minimap_trap_01.png':'CD_minimap_01.png'),'CD_minimap_portal.png'];let x=0;
 s.minimapCount=frames.length;s.minimapRoom=0;
 for(const [i,name]of frames.entries()){await P.preloadFrame(name);const sprite=cc.Sprite.createWithSpriteFrameName(name);sprite.setAnchorPoint(0,0);sprite.setPosition(x,0);mini.addChild(sprite);const red=name.replace('CD_minimap_portal','CD_minimap_portal_red').replace('CD_minimap_door','CD_minimap_door_red').replace('CD_minimap_trap_','CD_minimap_red_trap_').replace('CD_minimap_01','CD_minimap_red_01');await P.preloadFrame(red);const overlay=cc.Sprite.createWithSpriteFrameName(red);overlay.setAnchorPoint(0,0);overlay.setPosition(x,0);mini.addChild(overlay,0,i);overlay.setVisible(i===0);x+=sprite.getContentSize().width;}
 await Promise.all(['CD_menu_button_00.png','CD_menu_button_01.png','CD_UI_orb_glass_03.png','CD_UI_orb_gauges.png','CD_auto_speed_00.png','CD_auto_speed_01.png'].map(P.preloadFrame));
 const menu=s.hudMenu=cc.Menu.create();menu.setPosition(0,0);s.host.addChild(menu,100);
 const image=n=>cc.Sprite.createWithSpriteFrameName(n),button=s.mainMenuButton=cc.MenuItemSprite.create(image('CD_menu_button_00.png'),image('CD_menu_button_01.png'),()=>{if(!P.modal&&s.mode===0)P.openEntertain(5).catch(P.fail);});button.setPosition(880,508);menu.addChild(button);
 // StageScene::init, 0x21eb04 wraps the (105,40) money node in a 210x80
 // menu item at winSize-(107,42). It is not a bottom-left HUD child.
 const wallet=s.walletButton=cc.MenuItemSprite.create(money,null,()=>{if(!P.modal&&s.mode===0)P.openShop().catch(P.fail);});wallet.setPosition(853,598);menu.addChild(wallet);
 const orb=s.orbGlass=image('CD_UI_orb_glass_03.png'),gauge=s.orbGauge=image('CD_UI_orb_gauges.png');orb.setPosition(890,320);gauge.setAnchorPoint(.5,0);gauge.setPosition(891,320-gauge.getContentSize().height/2+5);s.host.addChild(orb,3);s.host.addChild(gauge,3);const number=s.orbNumber=cc.LabelTTF.create('',P.text('local_font'),13);number.setAnchorPoint(.5,0);number.setPosition(orb.getContentSize().width/2+3,9);orb.addChild(number);
 const speed=s.speed=cc.MenuItemSprite.create(image('CD_auto_speed_01.png'),null,()=>{P.profile.client.speedUp=!P.profile.client.speedUp;P.save();P.updateSpeed();});speed.setPosition(960-speed.getContentSize().width/2-20,speed.getContentSize().height/2+20);menu.addChild(speed);
 P.updateStageMoney();P.updateSpeed();P.updateStageHUD();
};
// StageScene::update, 0x21f06c: the top-right menu/wallet is hidden during
// selection/dialogue/combat phases, and raised80px during ordinary walking.
P.updateStageHUD=function(){const s=P.stage;if(!s)return;if(s.hudMenu){s.hudMenu.setVisible(s.mode===0||s.mode===1);s.hudMenu.setPosition(0,s.mode===1?80:0);} // MENU belongs to preparation, never to the heroes' entrance/walk.
 s.mainMenuButton?.setVisible(s.mode===0&&!s.battle);for(let i=0;i<(s.minimapCount||0);i++)s.minimap.getChildByTag(i)?.setVisible(i===(s.minimapRoom||0));};
P.updateSpeed=function(){const up=!!P.profile.client.speedUp;cc.Director.getInstance().getScheduler().setTimeScale(up?3:1);if(P.stage?.speed)P.stage.speed.setNormalImage(cc.Sprite.createWithSpriteFrameName('CD_auto_speed_0'+(up?0:1)+'.png'));};
P.updateStageMoney=function(){const s=P.stage,v=P.profile.server;if(!s)return;s.money?.getChildByTag(0)?.setString(v.gold.toLocaleString('en-US'));s.money?.getChildByTag(1)?.setString(v.gem.toLocaleString('en-US'));s.deck?.getChildByTag(500)?.m_lblAmount?.setString('X'+Math.min(99,v.traps));const n=v.orbBalance+(s.battle&&!s.result?Math.min(3,s.battle.kills):0);s.orbNumber?.setString(n>=100?'MAX':String(Math.floor(n/10)));s.orbGauge?.setScaleY(n>=100?1:(n%10)/10);};
P.reloadQuest=async function(root){
 const s=P.profile.server;P.rules.refresh(s,Date.now());P.save();root.nativeQuestRevision=P.questRevision||0;root.nativeQuestDay=P.rules.localDay();const slot=s.claimedQuests.findIndex(n=>n!==1);root.nativeQuestSlot=slot;root.m_layerQuest.setVisible(slot!==-1&&P.stage.index!==0);if(slot===-1)return;
 const id=s.activeQuests[slot],required=P.data.questRequirements[id-1],progress=Math.min(required,s.questProgress[id-1]);root.m_lblQuestNum.setString(String(slot+1));root.m_lblReward.setVisible(slot<2);root.m_lblReward.setString(String([1000,3000,5][slot]));root.m_lblQuestDes.setDimensions(cc.size(0,0));root.m_lblQuestDes.setString(P.text('local_dailyquestdes'+String(id).padStart(2,'0'))+'('+progress+'/'+required+')');P.fitLabel(root.m_lblQuestDes,360,15);
 const name='CD_quest_button_'+(slot===2?'gem':'coin')+'_0'+(progress>=required?1:0)+'.png';await P.preloadFrame(name);root.m_menuReward.getChildByTag(0).setNormalImage(cc.Sprite.createWithSpriteFrameName(name));
 root.m_layerQuest.getChildByTag(19994)?.removeFromParent(true);const frame='CD_quest_progress_0'+(slot*2+1)+'.png';await P.preloadFrame(frame);const marker=cc.Sprite.createWithSpriteFrameName(frame);marker.setPosition(-340,255);root.m_layerQuest.addChild(marker,10,19994);
};
P.controllers.get('StageLeverUI').onCallbackReward=async function(){const slot=this.nativeQuestSlot;if(slot<0)return;const s=P.profile.server,id=s.activeQuests[slot];if(s.questProgress[id-1]<P.data.questRequirements[id-1])return;const r=P.request('/quest_clear',{quest_id:id});if(!r.ok)return P.notice(P.errorText(r.error));await P.reloadQuest(this);P.updateStageMoney();P.stageActions();};
P.handleTutorialMessage=async function(message){
 const s=P.stage;
 P.actions([]);
 if(message==='Tutorial_8'||message==='Tutorial_Gotcha02'){s.mode=11;await P.stageHand(930,354);P.after(s.host,.5,()=>P.stageActions());}
 else if(message==='Tutorial_11sub1'||message==='Tutorial_SelectMonster02'){s.mode=11;await P.stageHand(930,254);P.after(s.host,.5,()=>P.stageActions());}
 else if(message==='Tutorial_12sub1'){
  P.removeStageHand();await P.preloadFrame('CD_UI_arrow.png');const arrow=cc.Sprite.createWithSpriteFrameName('CD_UI_arrow.png');arrow.setPosition(220,180);s.host.addChild(arrow,105,19993);s.mode=10;
  P.after(s.host,3,()=>{arrow.removeFromParent(true);P.talk(s.host,2,12).catch(P.fail);});
 }else if(message==='Tutorial_End'){
  if(P.profile.client.tutorial<5){P.profile.client.tutorial=6;P.save();await P.handleTutorialMessage('Tutorial_Gotcha02');}else{s.mode=0;P.stageActions();await P.maybeDailyReward?.();}
 }else return false;
 return true;
};
})();
