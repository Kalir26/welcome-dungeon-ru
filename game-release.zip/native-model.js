/* Mechanical port of v98's LocalGameServer / NativeMonsterData, not the old
 * browser prototype. Native client-only state is deliberately kept separate. */
(function(scope){
'use strict';
const MAX=2147483647,clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const copy=o=>JSON.parse(JSON.stringify(o));
class NativeRules{
 constructor(data,random=Math.random){this.d=data;this.random=random;this.byId=new Map(data.characters.map(c=>[c.id,c]));}
 character(id){const c=this.byId.get(id);if(!c)throw Error('Unknown native character '+id);return c;}
 stars(id){this.character(id);return this.d.stars[id-4000];}
 threshold(id,level){const s=Math.min(this.stars(id),5)-1,n=level-1;return [50,80,100,120,150][s]+n*[60,100,124,150,190][s]+n*(n-1)*[5,10,12,15,20][s]/2;}
 maxLevel(id){this.stars(id);return this.d.maxLevel[id-4000];}
 monsterLevel(id,xp){for(let l=1;l<this.maxLevel(id);l++)if(this.threshold(id,l)>xp)return l;return this.maxLevel(id);}
 limitedExp(id,xp){const m=this.maxLevel(id);return clamp(xp,0,m<=1?0:this.threshold(id,m-1));}
 feedExp(mon){if(mon.id>=4083&&mon.id<=4094)return this.d.foodXP[mon.id-4083];const g=this.stars(mon.id)-1;return this.d.feedBase[g]+(this.monsterLevel(mon.id,mon.exp)-1)*this.d.feedStep[g];}
 sellPrice(mon){const value=this.feedExp(mon);return mon.id>=4083&&mon.id<=4094?value:Math.trunc(value/2);}
 enhancePrice(mon,n){return (120+20*(this.monsterLevel(mon.id,mon.exp)-1))*n;}
 userLevel(xp){let l=1;for(const t of this.d.devilXP){if(xp<t)break;l++;}return Math.min(l,99);}
 frontier(xp){const l=this.userLevel(xp);return l===1?0:Math.min(16,Math.trunc(l/5)+1);}
 partySize(xp){const l=this.userLevel(xp);return l<5?3:l<10?4:l<15?5:l<25?6:l<35?7:l<45?8:l<55?9:l<65?10:l<75?11:12;}
 devilProgress(xp){const level=this.userLevel(xp),table=this.d.nativeDevilXP;if(level===99){const required=table[98]-table[97];return {level,current:required,required};}const start=level===1?0:table[level-2];return {level,current:xp-start,required:table[level-1]-start};}
 stats(id,level){const row=this.d.characterRows[id];if(!row)throw Error('Missing native character row '+id);const g=this.d.statGrowth[row[14]],n=level-1;return {id,level,attack:row[3]+n*g[1],defence:row[4]+n*g[2],hp:row[5]+n*g[0],maxHP:row[6]+n*g[0],element:this.character(id).element};}
 // GameManager::getTeamEffect checks the CURRENT deck, not the collection
 // gallery/seen flags, then applies completed sets in descending ID order.
 teamEffects(party){const ids=new Set(party.filter(Boolean).map(m=>m.id));return this.d.COLLECTIONS.flatMap((r,i)=>r.slice(1,6).every(id=>!id||ids.has(id))?[i]:[]).reverse();}
 applyTeamEffects(stats,effects,factionFlag=0,colors){const stars=stats.id>=4000&&stats.id<4104?this.stars(stats.id):0;for(const i of effects){const [stat,condition,value,amount]=this.d.nativeTeamEffects[i];const match=condition==='all'||condition==='stars'&&stars===value||condition==='element'&&stats.element===value||condition==='faction'&&factionFlag===value||condition==='maxLevel'&&stats.level<=value;if(!match||stat==='gold')continue;if(stat==='hp'){stats.hp+=amount;stats.maxHP+=amount;}else stats[stat]=Math.trunc(stats[stat]*amount);if(colors)colors[i===27?'defence':stat]=true;}return stats;}
 teamStats(id,level,party,factionFlag=0,colors){return this.applyTeamEffects(this.stats(id,level),this.teamEffects(party),factionFlag,colors);}
 // CObject::GetDamage 0x1fcc58. Native enum: fire=0, tree=1, water=2,
 // light=3. factionFlag is the original +0x1a0 flag, not an element guess.
 damage(attacker,target,ignoreAttribute=false){let m=1;const a=attacker.element,b=target.element;if(!ignoreAttribute&&a!==b){if(a===3)m=target.factionFlag===1?1:1.25;else if(b===3)m=attacker.factionFlag===1?1:.75;else m=((a+1)%3===b)?1.25:.75;}return Math.max(1,Math.trunc(Math.fround(Math.fround(attacker.attack)*Math.fround(m)))-target.defence);}
 localDay(now=Date.now(),offset=new Date(now).getTimezoneOffset()){return Math.floor((now-offset*60000)/86400000);}
 dailyQuests(day){const out=[];for(let i=0;i<3;i++){const p=this.d.QUEST_POOLS[i];let pos=((day*(i+1)+i)%p.length+p.length)%p.length;while(out.includes(p[pos]))pos=(pos+1)%p.length;out.push(p[pos]);}return out;}
 fresh(now=Date.now()){const day=this.localDay(now);return {version:1,client:{tutorial:0,newStages:Array(17).fill(false),language:'ru'},server:{clearedStages:0,gold:0,gem:0,userExp:0,summonCounter:0,nextSequence:1,monsters:[],party:Array(12).fill(0),stageOrbs:Array(17).fill(0),traps:0,orbBalance:0,tutorialStep:0,tripPoints:0,gemBonusCount:0,activeTrip:0,pendingSuccubus:0,questDay:day,activeQuests:this.dailyQuests(day),questProgress:Array(19).fill(0),claimedQuests:Array(3).fill(0),seenMonsters:Array(104).fill(0),claimedCollections:Array(28).fill(0),dailyRewardDay:-1,dailyRewardCycle:0}};}
 randomInt(n){return typeof this.random.nextInt==='function'?this.random.nextInt(n):Math.floor(this.random()*n);}
 choose(a){return a[this.randomInt(a.length)];}
 refresh(s,now){const day=this.localDay(now);if(day>s.questDay){s.questDay=day;s.questProgress.fill(0);s.claimedQuests.fill(0);s.activeQuests=this.dailyQuests(day);}}
 collectionComplete(s,id){const r=this.d.COLLECTIONS[id-1];return !!r&&r.slice(1,6).every(n=>n===0||s.seenMonsters[n-4000]===1);}
 addMonster(s,id,quest=false,rare=false){if(s.monsters.length>=100)return 0;const seq=s.nextSequence++;s.monsters.push({seq,id,exp:0});s.seenMonsters[id-4000]=1;if(quest){s.summonCounter++;for(const q of [5,6,7,rare?13:12])s.questProgress[q]++;const stars=this.stars(id);if(stars===3)s.questProgress[8]++;if(stars===2)s.questProgress[9]++;}return seq;}
 sanitize(s){const used=new Set();s.party=s.party.map((seq,i)=>{if(i>=this.partySize(s.userExp)||seq<0||!s.monsters.some(m=>m.seq===seq)||used.has(seq))return 0;used.add(seq);return seq;});}
 remove(s,seqs){s.monsters=s.monsters.filter(m=>!seqs.includes(m.seq));this.sanitize(s);while(s.pendingSuccubus>0&&s.monsters.length<100){s.pendingSuccubus--;this.addMonster(s,4005);}}
 // Failed requests leave all gameplay balances and party data unchanged. The
 // same day-rollover semantics as the APK are applied before each request.
 request(profile,endpoint,body={},now=Date.now()){
  const old=profile.server;this.refresh(old,now);const s=copy(old),reward={gold:0,userExp:0,monsterExp:0,orbs:0,eventGold:0,gem:0,wheelGem:0,levelUpGem:0,merchantCost:0,monsters:[],daily:null};
  const fail=error=>({ok:false,error,reward:null});const done=()=>{profile.server=s;return {ok:true,error:'',reward};};
  const mon=seq=>s.monsters.find(m=>m.seq===seq),placed=seq=>s.party.includes(seq),integer=n=>Number.isSafeInteger(n),positive=n=>integer(n)&&n>=0;
  if(endpoint==='/login'){
   if(s.activeTrip){s.orbBalance+=this.d.TRIPS[s.activeTrip-1][1]*10;s.activeTrip=0;}
   const today=Math.floor(now/86400000);if(today>s.dailyRewardDay){s.dailyRewardCycle=s.dailyRewardCycle%this.d.DAILY_REWARDS.length+1;const [type,value]=this.d.DAILY_REWARDS[s.dailyRewardCycle-1];s[type===2?'gem':'traps']=Math.min(MAX,s[type===2?'gem':'traps']+value);s.dailyRewardDay=today;reward.daily={type,value,cycle:s.dailyRewardCycle};}return done();
  }
  if(['/version','/welcome','/welcomed','/save_upload'].includes(endpoint))return done();
  if(endpoint==='/party_setting'){
   const p=body.party_list;if(!Array.isArray(p)||p.length>this.partySize(s.userExp)||p.some(n=>!positive(n)||n>0&&!mon(n))||new Set(p.filter(Boolean)).size!==p.filter(Boolean).length)return fail('Invalid party data');
   s.party=Array.from({length:12},(_,i)=>p[i]||0);this.sanitize(s);if([2,4,6].includes(s.tutorialStep)&&p.includes(s.tutorialStep/2)){if(s.tutorialStep===2)s.gold+=10000;s.tutorialStep++;}return done();
  }
  if(endpoint==='/mon_sell'){
   const m=mon(body.seq);if(!m||placed(m.seq)||s.monsters.length<=1)return fail('Cannot sell this monster');s.gold+=this.sellPrice(m);this.remove(s,[m.seq]);return done();
  }
  if(endpoint==='/mon_feed'){
   const m=mon(body.seq),f=body.feed_list;if(!m||!Array.isArray(f)||f.length<1||f.length>10||this.monsterLevel(m.id,m.exp)>=this.maxLevel(m.id))return fail('Invalid strengthening data');if(new Set(f).size!==f.length||f.some(n=>!mon(n)||n===m.seq||placed(n)))return fail('Invalid strengthening material');const price=this.enhancePrice(m,f.length);if(s.gold<price)return fail('Not enough gold');s.gold-=price;const oldLevel=this.monsterLevel(m.id,m.exp);m.exp=this.limitedExp(m.id,m.exp+f.reduce((v,n)=>v+this.feedExp(mon(n)),0));if(this.monsterLevel(m.id,m.exp)>oldLevel)s.questProgress[10]++;this.remove(s,f);return done();
  }
  const normal=endpoint==='/gacha_normal'||endpoint==='/gacha_normal_10',rare=endpoint==='/gacha_rare'||endpoint==='/gacha_rare_10';
  if(normal||rare){
   if(s.tutorialStep<7){if(endpoint!=='/gacha_normal'||![1,3,5].includes(s.tutorialStep))return fail('Finish the indicated tutorial action first');if(s.gold<5000)return fail('Not enough gold');s.gold-=5000;reward.monsters.push(this.addMonster(s,[4001,4002,4003][Math.trunc((s.tutorialStep-1)/2)],true));s.tutorialStep++;return done();}
   const count=endpoint.endsWith('_10')?10:1,price=normal?(count===10?45000:5000):(count===10?360:40),key=normal?'gold':'gem';if(s.monsters.length+count>100)return fail('Monster box is full');if(s[key]<price)return fail('Not enough currency');s[key]-=price;const pool=this.d.stars.flatMap((stars,i)=>stars>=(rare?3:1)&&stars<=(rare?6:4)?[4000+i]:[]);
   for(let i=0;i<count;i++){if(normal&&this.randomInt(10)===0){reward.monsters.push(-1);s.traps++;s.summonCounter++;for(const q of [5,6,7,12])s.questProgress[q]++;}else reward.monsters.push(this.addMonster(s,this.choose(pool),true,rare));}return done();
  }
  if(endpoint==='/spin_gold'){const n=body.spin_gold;if(!positive(n)||n>MAX-s.gold)return fail('Invalid coin reward');s.gold+=n;return done();}
  if(endpoint==='/stage_clear'){
   const clear=body.clear_yn??0,stage=body.stage;if(![0,1].includes(clear))return fail('Invalid battle result');const orb=clamp(body.earn_orb||0,0,3);
   if(stage===0){if(s.tutorialStep!==0||clear===0)return done();s.userExp=600;s.gold+=5000;s.gem+=100;s.orbBalance+=orb;s.stageOrbs[0]=orb;s.clearedStages=1;s.tutorialStep=1;Object.assign(reward,{gold:5000,userExp:600,orbs:orb,gem:95,levelUpGem:5});return done();}
   const previousLevel=this.userLevel(s.userExp),frontier=Math.min(16,Math.trunc(previousLevel/5)+1),event=body.event||0;if(!integer(stage)||stage<1||stage>frontier)return fail('Invalid battle result');if(event===1005&&s.gold<3000)return fail('Not enough gold for the merchant');const traps=body.use_trap||0;if(!positive(traps)||traps>s.traps)return fail('Invalid trap use');s.traps-=traps;
   const symbols=[body.spin_1,body.spin_2,body.spin_3];[10,13,14,16,15].forEach((n,q)=>{if(symbols.includes(n))s.questProgress[14+q]++;});s.orbBalance+=orb;reward.orbs=orb;
   if(clear===1){s.clearedStages=Math.max(s.clearedStages,stage+1);s.stageOrbs[stage]=Math.max(s.stageOrbs[stage],orb);reward.gold=500;s.gold+=500;}
   if(event===1001)reward.eventGold=1000;else if(event===1002)reward.eventGold=1000+(previousLevel-1)*50;else if(event===1003)reward.eventGold=500;else if(event===1004){s.gem++;reward.gem++;if(!clear)s.clearedStages=Math.max(s.clearedStages,stage+1);}else if(event===1005){s.gold-=3000;reward.merchantCost=3000;}else if(event===1006){const seq=this.addMonster(s,4005);if(seq)reward.monsters.push(seq);else s.pendingSuccubus++;}
   if(clear===1||event===1004){s.questProgress[0]++;s.questProgress[1]++;if(stage===frontier){reward.userExp=100*stage;reward.monsterExp=6*stage;s.userExp+=reward.userExp;s.gemBonusCount=s.gemBonusCount>=10?1:s.gemBonusCount+1;if(s.gemBonusCount===10){reward.wheelGem=this.choose([1,2,3,5,10]);reward.gem+=reward.wheelGem;s.gem+=reward.wheelGem;}}}
   if(!clear&&!event&&symbols.includes(10)){reward.merchantCost=Math.min(s.gold,1000);s.gold-=reward.merchantCost;}s.gold+=reward.eventGold;reward.levelUpGem=Math.max(0,this.userLevel(s.userExp)-previousLevel)*5;s.gem+=reward.levelUpGem;
   if(reward.monsterExp)for(const seq of s.party){const m=mon(seq);if(m)m.exp=this.limitedExp(m.id,m.exp+reward.monsterExp);}return done();
  }
  if(endpoint==='/trap_buy'){if(s.gem<5)return fail('Not enough gem');if(s.traps>MAX-5)return fail('Trap inventory is full');s.gem-=5;s.traps+=5;return done();}
  if(endpoint==='/collection'){
   const id=body.col_id;if(!this.collectionComplete(s,id))return fail('Collection is incomplete');if(s.claimedCollections[id-1])return fail('Reward already received');const r=this.d.COLLECTIONS[id-1];s[['gold','gem','traps'][r[6]]]+=r[7];s.claimedCollections[id-1]=1;return done();
  }
  if(endpoint==='/quest_clear'){
   const id=body.quest_id,slot=s.activeQuests.indexOf(id);if(slot<0)return fail('Invalid daily quest');if(s.claimedQuests[slot])return fail('Reward already received today');if(s.questProgress[id-1]<this.d.questRequirements[id-1])return fail('Daily quest is incomplete');s[slot<2?'gold':'gem']+=[1000,3000,5][slot];s.claimedQuests[slot]=1;return done();
  }
  if(endpoint==='/trip_ent'){
   const id=body.trip_id;if(!this.collectionComplete(s,id)||!s.claimedCollections[id-1])return fail('Claim the collection reward first');if(s.monsters.length>=100)return fail('Monster box is full');if(s.activeTrip)return fail('An adventure is already active');const cost=this.d.TRIPS[id-1][1]*10;if(s.orbBalance<cost)return fail('Not enough orb');s.orbBalance-=cost;s.activeTrip=id;s.questProgress[11]++;return done();
  }
  if(endpoint==='/trip_clear'){
   const id=body.trip_id;if(!integer(id)||id<1||id>28||s.activeTrip!==id)return fail('No matching active adventure');const gold=body.earn_gold||0,gem=body.earn_gem||0,traps=body.earn_trap||0,points=body.earn_trip_point||0,mob=body.earn_mon_id||0;if(!integer(gold)||s.gold+gold<0||s.gold+gold>MAX||!positive(gem)||s.gem+gem>MAX||!positive(traps)||s.traps+traps>MAX||!positive(points)||s.tripPoints+points>MAX||(mob&&(!integer(mob)||mob<4000||mob>4103||s.monsters.length>=100)))return fail('Invalid adventure rewards');if(mob)reward.monsters.push(this.addMonster(s,mob));s.gold+=gold;s.gem+=gem;s.traps+=traps;s.tripPoints+=points;s.activeTrip=0;return done();
  }
  return fail('This online service is unavailable offline');
 }
}
scope.NativeRules=NativeRules;if(typeof module!=='undefined')module.exports=NativeRules;
})(typeof window==='undefined'?globalThis:window);
