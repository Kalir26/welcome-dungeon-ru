/* CCBGotcha::makeMenu and GotchaAnimationLayer: original six image buttons,
 * 50-card shuffle, CCB card reveal, transactional summons and tutorial steps. */
(function(){
'use strict';const P=window.NativePort,sprite=name=>cc.Sprite.createWithSpriteFrameName(name);
const menuLabels={0:'Закрыть призыв',1:'Призвать за 5000 золота',2:'Призвать за 40 гемов',3:'Магазин',6:'Призвать 10 за 45000 золота',7:'Призвать 10 за 360 гемов',8:'Бесплатные гемы'};
P.gotchaActions=function(root){if(P.modal!==root)return;if(root.nativeGacha.busy)return P.actions([{label:'Пропустить анимацию призыва',run:()=>P.skipGotcha(root)}]);const tutorial=P.profile.client.tutorial;if([2,6,8].includes(tutorial))P.actions([{label:menuLabels[1],run:()=>P.gotchaButton(root,1)}]);else if([3,7,9].includes(tutorial))P.actions([{label:menuLabels[0],run:()=>P.closeGotcha(root)}]);else P.menuActions(root,menuLabels);};
P.openGotcha=async function(){
 const root=await P.panel('ccb/CD_UI_gotcha.ccbi',{shade:0});root.nativeGacha={busy:false,queue:[],root};P.stage.gotcha=root;
 root.m_lblGotchaTitle.setString(P.text('local_gotchatitle'));root.m_lblGotchaTitle.setFontName(P.text('local_fontBold'));P.fitLabel(root.m_lblGotchaTitle,315,20);P.money(root);
 [root.m_lblNormalPrice,root.m_lblRarePrice,root.m_lblEpicPrice].forEach(n=>n.setVisible(false));
 root.m_menuGotcha.getChildren().forEach(b=>b.setVisible([0,3].includes(b.getTag())));
 const menu=root.nativeGotchaMenu=cc.Menu.create();menu.setPosition(0,0);menu.setTouchPriority(-2002);root.addChild(menu,10);
 const specs=[[6,3,4,-300,-110,45000,80],[7,7,8,0,-110,360,100],[3,9,10,300,-110,null,0],[1,1,2,-300,70,5000,80],[2,5,6,0,70,40,100],[8,11,12,300,70,null,0]];
 await Promise.all(Array.from({length:13},(_,i)=>'gacha_'+String(i+1).padStart(2,'0')+'.png').map(P.image));
 for(const [tag,on,off,x,y,price,px]of specs){const normal=cc.Sprite.create('gacha_'+String(on).padStart(2,'0')+'.png'),selected=cc.Sprite.create('gacha_'+String(off).padStart(2,'0')+'.png');if(price!==null)for(const [n,py]of [[normal,21],[selected,17]]){const label=cc.LabelTTF.create(String(price),P.text('local_font'),20);label.setAnchorPoint(0,0);label.setPosition(px,py);n.addChild(label);}
  const button=cc.MenuItemSprite.create(normal,selected,()=>{if(P.modal===root)P.gotchaButton(root,tag).catch(P.fail);});button.setPosition(x,y);button.setTag(tag);menu.addChild(button);
  if(tag===6||tag===7){const badge=cc.Sprite.create('gacha_13.png');badge.setPosition(5,button.getContentSize().height);button.addChild(badge);}
 }
 P.notifications.set('GotchaScene',async message=>{if(message==='Tutorial_9'||message==='Tutorial_10'){P.gotchaActions(root);return;}throw Error('Unexpected GotchaScene message '+message);});
 P.status('Призыв монстров');P.gotchaActions(root);
 if(P.profile.client.tutorial===2)await P.panelTalk(8);
 return root;
};
P.gotchaButton=async function(root,tag){
 if(root.nativeGacha.busy)return;const tutorial=P.profile.client.tutorial;
 if([2,6,8].includes(tutorial)&&tag!==1)return;
 if([3,7,9].includes(tutorial)&&tag!==0)return;
 if(tag===0)return P.closeGotcha(root);
 if(tag===3)return P.openShop();
 if(tag===8)return P.freeGemsNotice();
 const endpoints={1:'/gacha_normal',2:'/gacha_rare',6:'/gacha_normal_10',7:'/gacha_rare_10'},endpoint=endpoints[tag];if(!endpoint)return;
 const r=P.request(endpoint);if(!r.ok){const gold=tag===1||tag===6;const key=/box/.test(r.error)?'local_popupinvenisfull':gold?'local_popupnotenoughmoney':'local_popupnotenoughgem';return P.notice(P.text(key));}
 if([2,6,8].includes(tutorial)){P.profile.client.tutorial=tutorial===2?3:tutorial+1;P.save();}
 root.nativeGacha.queue=r.reward.monsters.slice();root.nativeGacha.rare=tag===2||tag===7;root.nativeGacha.ten=tag===6||tag===7;
 root.nativeGacha.busy=true;root.m_layerWillHidden.setVisible(false);root.nativeGotchaMenu.setVisible(false);root.m_menuSkip.setVisible(true);P.money(root);P.gotchaActions(root);
 await P.nextGotcha(root);
};
P.nextGotcha=async function(root){
 const state=root.nativeGacha,seq=state.queue.shift(),mon=seq===-1?null:P.profile.server.monsters.find(m=>m.seq===seq);if(seq!==-1&&!mon)throw Error('Summoned monster is absent from saved inventory');state.current=mon;state.currentSeq=seq;state.revealed=false;state.animating=true;
 if(state.ten)return P.revealGotcha(root,true);
 const c=P.data.nativeGotcha,colors=state.rare?['silver','silver','gold','gold','red']:['black','black','silver','silver','gold'],chosen=colors[(mon?P.rules.stars(mon.id):0)-(state.rare?2:0)];state.cardColor=chosen;
 const names=[...new Set(colors.map(color=>'CD_UI_inventory_card_'+color+'.png'))];await Promise.all(names.map(P.preloadFrame));
 const clip=state.clip=P.rectangleClip(940,620);root.m_layercard.addChild(clip);const reel=state.reel=cc.Layer.create();reel.setContentSize(0,0);reel.setPosition(470,310);clip.addChild(reel);
 for(let i=0;i<50;i++){const name=i===30?'CD_UI_inventory_card_'+chosen+'.png':names[Math.floor(Math.random()*names.length)],card=sprite(name);card.setPosition(i*c.rowStep+c.rowOffset,c.rowY);reel.addChild(card);}
 const end=cc.CallFunc.create(()=>P.revealGotcha(root,false).catch(P.fail));
 if(Math.floor(Math.random()*2)===0)reel.runAction(cc.Sequence.create(cc.EaseSineInOut.create(cc.MoveBy.create(c.duration,cc.p(c.travelOver,0))),cc.EaseExponentialOut.create(cc.MoveBy.create(2,cc.p(c.return,0))),cc.DelayTime.create(.5),end));
 else reel.runAction(cc.Sequence.create(cc.DelayTime.create(2),cc.EaseExponentialOut.create(cc.MoveBy.create(c.duration,cc.p(c.travel,0))),cc.DelayTime.create(.5),end));
 P.audio.play('gotcha_dark.mp3').catch(P.fail);P.after(root,1,()=>P.audio.play('gotcha_cardshuffle.mp3').catch(P.fail));
};
P.skipGotcha=function(root){const state=root.nativeGacha;if(!state.animating)return;state.reel?.stopAllActions();P.revealGotcha(root,state.ten).catch(P.fail);};
P.revealGotcha=async function(root,ten){
 const state=root.nativeGacha;if(state.revealed)return;state.revealed=true;state.clip?.removeFromParent(true);state.clip=null;
 const effect=await P.readScene('ccb/CD_card_effect.ccbi');state.effect=effect;effect.nativeGotchaRoot=root;effect.setPosition(470,360);root.m_layercard.addChild(effect);
 effect.nativeAnimation.runAnimationsForSequenceNamed(ten?'card_summon_00':'card_'+state.cardColor+'_down');
};
P.controllers.set('CCBGotchaSummon',{completed:function(name){P.gotchaEffectCompleted(this,name).catch(P.fail);}});
P.gotchaEffectCompleted=async function(effect,name){
 const root=effect.nativeGotchaRoot;if(!root||!root.getParent())return;const state=root.nativeGacha;
 if(/_down$/.test(name))P.audio.play('gotcha_monstercameout.mp3').catch(P.fail);
 else if(name==='card_summon_00'){
  const frame=state.current?state.current.id+'.png':'CD_UI_trab_card_back.png';await P.preloadFrame(frame);const portrait=sprite(frame);portrait.setAnchorPoint(.5,0);portrait.setPosition(0,P.data.nativeGotcha.portraitY);if(!state.current)portrait.setScale(.5);effect.m_layerSummon.addChild(portrait,0,445);
  P.audio.play('gotcha_cardshining.mp3').catch(P.fail);effect.nativeAnimation.runAnimationsForSequenceNamed('card_summon_01');
 }else if(name==='card_summon_01'){
  state.animating=false;await P.gotchaConfirm(root);
 }
};
P.gotchaConfirm=async function(root){
 const state=root.nativeGacha,confirm=await P.panel('ccb/card_confirm.ccbi',{position:[480,370],shade:0});confirm.nativeGotchaRoot=root;
 if(state.current){const card=await P.monsterCard(state.current);confirm.addChild(card);}else{await P.preloadFrame('CD_UI_trab_card_back.png');confirm.addChild(sprite('CD_UI_trab_card_back.png'));}
 P.menuActions(confirm,['Подтвердить призыв']);P.status('Монстр призван',state.current?P.monsterName(state.current.id):'Карта ловушки');
 if(state.queue.length){P.nativeMenus(confirm).forEach(m=>m.setVisible(false));P.actions([]);P.after(confirm,1,()=>P.confirmGotcha(confirm).catch(P.fail));}
 else if(P.profile.client.tutorial===3)await P.panelTalk(9);
};
P.confirmGotcha=async function(confirm){const root=confirm.nativeGotchaRoot,state=root.nativeGacha;P.closePanel(confirm);state.effect?.removeFromParent(true);state.effect=null;if(state.queue.length)return P.nextGotcha(root);state.busy=false;root.m_layerWillHidden.setVisible(true);root.nativeGotchaMenu.setVisible(true);root.m_menuSkip.setVisible(false);P.money(root);P.gotchaActions(root);};
P.controllers.set('CCardConfirm',{onConfirmCallback:async function(){await P.confirmGotcha(this);}});
P.closeGotcha=async function(root){
 if(root.nativeGacha.busy)return;P.closePanel(root);P.stage.gotcha=null;await P.refreshDeck();const t=P.profile.client.tutorial;
 if(t===3){P.stage.mode=10;await P.talk(P.stage.host,2,10);}else if(t===7||t===9)await P.handleTutorialMessage('Tutorial_SelectMonster02');else{P.stage.mode=0;P.stageActions();}
};
P.controllers.set('CCBGotcha',{onGotchaCallback:async function(sender){await P.gotchaButton(this,sender.getTag());},skipAnimation:function(){P.skipGotcha(this);}});
})();
