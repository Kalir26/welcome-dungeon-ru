/* CCardInfo, InventoryScene and party placement, original scene layout. */
(function(){
'use strict';const P=window.NativePort,sprite=name=>cc.Sprite.createWithSpriteFrameName(name);
P.money=function(root){root.m_lblMoney?.setString(P.profile.server.gold.toLocaleString('en-US'));root.m_lblGem?.setString(P.profile.server.gem.toLocaleString('en-US'));};
P.notice=async function(text,options={}){const previous=P.modal,actions=P.currentActions;P.modal=null;const root=await P.popup(P.currentRoot||P.stage.host,text,{...options,closed:async()=>{P.modal=previous;P.actions(actions||[]);await options.closed?.();}});if(previous)root.setZOrder(previous.getZOrder()+1);return root;};
P.panelTalk=async function(index,parent=P.stage.host){const previous=P.modal;P.modal=null;const talk=await P.talk(parent,2,index);talk.setZOrder((previous?.getZOrder()||200)+1);talk.nativeTalk.closed=()=>{if(!P.modal)P.modal=previous;};return talk;};
P.skillDescription=function(id,level){const c=P.data.nativeBattle,g=P.rules.stars(id)-1,n=level-1,k=c.skillByID[id],key=c.skillDescKeys[k];let value=0;if(k===1)value=c.healBase[g]+50*n;else if(k===2)value=c.poisonBase[g]+10*n;else if(k===3)value=c.splashBase[g]+30*n;else if(k===5)value=Math.min(.8,c.attackReduction[g]+.001*n)*100;else if(k===6)value=Math.min(.8,c.defenceReduction[g]+.003*n)*100;else if(k===7)value=Math.trunc(c.levelReduction[g]+.1*n);return P.text(key).replace(/%d/,String(value)).replace(/%\.1f/,(Math.round(value*10)/10).toFixed(1));};
// CCardSelect[Stage]::loadSelectData, 0x1fa52c /0x1faba8. The CCBI's
// placeholder icon position is replaced by the native code after loading.
P.displayCardSkill=async function(root,mon){const level=P.rules.monsterLevel(mon.id,mon.exp),frame='skill_'+P.data.nativeBattle.skillNames[P.data.nativeBattle.skillByID[mon.id]]+'_icon.png';await P.preloadFrame(frame);root.m_sprSkill.setDisplayFrame(cc.SpriteFrameCache.getInstance().getSpriteFrame(frame));root.m_sprSkill.setAnchorPoint(.5,0);root.m_sprSkill.setPosition(76,13);root.m_lblSkillDes.setString(P.skillDescription(mon.id,level));root.m_lblSkillDes.setFontName(P.text('local_font'));root.m_lblSkillDes.setFontSize(20);};
P.monsterCard=async function(mon,inventory=false){
 const c=P.rules.character(mon.id),grade=P.rules.stars(mon.id),color=P.data.nativeStage.cardColors[grade-1],level=P.rules.monsterLevel(mon.id,mon.exp),stats=P.rules.stats(mon.id,level);
 const names=['CD_UI_card_bg_'+color+'_00.png','summon_menu_'+c.name+'.png','CD_UI_card_bg_'+color+'.png','CD_UI_inventory_cardline_'+color+'.png','CD_UI_inventory_star.png','CD_UI_inventory_attribute_'+['fire','leaves','water','light'][c.element]+'.png','CD_UI_inventory_level.png','CD_UI_inventory_slash.png'];
 await Promise.all(names.map(P.preloadFrame));const root=await P.readScene('ccb/card_info.ccbi');root.nativeMonster=mon;
 root.m_layercardinfo.addChild(sprite(names[0]));root.m_layerMobImg.addChild(sprite(names[1]));root.m_layercardinfoFront.addChild(sprite(names[2]));root.addChild(sprite(names[3]));
 root.m_lblHP.setString(stats.hp+'/'+stats.maxHP);root.m_lblAtk.setString(String(stats.attack));root.m_lblDef.setString(String(stats.defence));
 if(inventory){root.m_lblHP.setPosition(15,-65);root.m_lblAtk.setPosition(-60,-100);root.m_lblDef.setPosition(35,-100);}
 const name=cc.LabelTTF.create(P.monsterName(mon.id),P.text('local_font'),P.language==='ru'?13:16);name.setPosition(0,inventory?102:100);root.m_layercardinfoFront.addChild(name);
 for(let i=0;i<grade;i++){const star=sprite(names[4]);star.setPosition(-80+i*32,-31);root.addChild(star);}
 const attr=sprite(names[5]);attr.setPosition(79,62);root.addChild(attr);
 const levels=cc.Sprite.create();levels.setAnchorPoint(0,0);levels.setPosition(-60,56);root.addChild(levels);
 const lv=await P.spriteNumber(level,'CD_UI_inventory_number',3),max=await P.spriteNumber(P.rules.maxLevel(mon.id),'CD_UI_inventory_number',3),slash=sprite(names[7]);lv.node.setPosition(0,0);levels.addChild(lv.node);slash.setAnchorPoint(0,0);slash.setPosition(lv.width+3,0);levels.addChild(slash);max.node.setPosition(lv.width+slash.getContentSize().width+9,0);levels.addChild(max.node);
 const label=sprite(names[6]);label.setAnchorPoint(0,0);label.setPosition(-30,0);levels.addChild(label);
 return root;
};
P.refreshDeck=async function(){const s=P.stage,old=s.deck;const deck=s.deck=await P.stageDeck();s.host.addChild(deck,105,6);old.removeFromParent(true);};
P.inventoryActions=function(root){P.actions(P.profile.server.monsters.map(m=>({label:P.monsterName(m.id)+' — уровень '+P.rules.monsterLevel(m.id,m.exp),run:()=>P.inspectMonster(m,root)})).concat([{label:'Закрыть ящик',run:()=>P.closeInventory(root)}]));};
P.scrollMenu=function(root,area,width,height){const Menu=cc.Menu.extend({onTouchBegan:function(t,e){if(P.modal!==root)return false;const p=area.convertToNodeSpace(t.getLocation());if(p.x<0||p.y<0||p.x>width||p.y>height)return false;return cc.Menu.prototype.onTouchBegan.call(this,t,e);}});const menu=new Menu();menu.initWithArray([]);menu.setPosition(0,0);menu.setTouchPriority(-2002);return menu;};
P.openInventory=async function(slot=null){
 const s=P.stage,root=await P.panel('ccb/CD_UI_inventory.ccbi',{shade:0});root.nativeSlot=slot;root.m_lblInvenTitle.setString(P.text('local_inventitle'));root.m_lblInvenTitle.setFontName(P.text('local_fontBold'));P.fitLabel(root.m_lblInvenTitle,315);P.money(root);root.m_lblInventoryCount.setString('('+String(P.profile.server.monsters.length).padStart(2,'0')+'/100)');
 const clip=P.rectangleClip(940,550);root.m_layerForScroll.addChild(clip);const content=root.nativeContent=cc.Layer.create();content.setContentSize(Math.max(940,(Math.floor(P.profile.server.monsters.length/2)+1)*230),550);clip.addChild(content);
 const menu=P.scrollMenu(root,root.m_layerForScroll,940,550);content.addChild(menu);
 await P.preloadFrame('CD_UI_inventory_card_red.png');
 for(const [i,mon]of P.profile.server.monsters.entries()){
  const blank=sprite('CD_UI_inventory_card_red.png'),button=cc.MenuItemSprite.create(blank,null,()=>{if(P.modal===root&&!root.nativeDragging)P.inspectMonster(mon,root).catch(P.fail);});
  button.setPosition(Math.floor((i+1)/2)*230+120,(i%2)*270+140);button.setTag(mon.seq);menu.addChild(button);
  const card=await P.monsterCard(mon,true);card.setPosition(blank.getContentSize().width/2,blank.getContentSize().height/2);button.addChild(card);
  if(P.profile.server.party.includes(mon.seq)){await P.preloadFrame('CD_UI_card_basic.png');const marker=sprite('CD_UI_card_basic.png');marker.setPosition(-62,100);card.addChild(marker);const label=cc.LabelTTF.create(P.language==='ru'?'В отряде':'in use',P.text('local_font'),8);label.setPosition(30,21);marker.addChild(label);}
 }
 P.installHorizontalDrag(root,content,root.m_layerForScroll,940,550);
 P.status('Ящик монстров');P.inventoryActions(root);
 return root;
};
P.closeInventory=async function(root){
 if([3,7,9].includes(P.profile.client.tutorial)&&P.profile.server.tutorialStep<7)return;
 P.closePanel(root);await P.refreshDeck();P.stageActions();
};
P.installHorizontalDrag=function(root,content,area,width,height){
 const Touch=cc.Layer.extend({ctor:function(){this._super();this.setContentSize(0,0);this.setTouchMode(cc.TOUCH_ONE_BY_ONE);this.setTouchPriority(-2004);this._swallowTouch=false;this.setTouchEnabled(true,false);},onTouchBegan:function(t){if(P.modal!==root)return false;const p=area.convertToNodeSpace(t.getLocation());if(p.x<0||p.y<0||p.x>width||p.y>height)return false;this.lastX=this.startX=t.getLocation().x;root.nativeDragging=false;return true;},onTouchMoved:function(t){const x=t.getLocation().x;root.nativeDragging=root.nativeDragging||Math.abs(x-this.startX)>5;content.setPositionX(Math.max(Math.min(0,content.getPositionX()+x-this.lastX),Math.min(0,width-content.getContentSize().width)));this.lastX=x;},onTouchEnded:function(){P.after(root,0,()=>{root.nativeDragging=false;});}});root.addChild(new Touch());
};
P.inspectMonster=async function(mon,inventoryRoot){
 const container=await P.panel('ccb/card_select.ccbi');container.nativeSelection={mon,inventoryRoot};
 // CardSelectLayer::loadInventoryUI: selector (-120,0), card (-120,100).
 container.setPosition(360,320);const card=await P.monsterCard(mon);card.setPosition(0,100);container.addChild(card);
 container.m_lblSellPrice.setString(String(P.rules.sellPrice(mon)));await P.displayCardSkill(container,mon);
 if(P.isPartyTutorial())for(const menu of P.nativeMenus(container))for(const button of menu.getChildren())if(button.getTag()===1||button.getTag()===4)button.setVisible(false);
 P.menuActions(container,{1:'Усилить',2:'Поставить в отряд',3:'Закрыть карту',4:'Продать'});P.status('Карта монстра',P.monsterName(mon.id));return container;
};
P.placeMonster=async function(mon,slot,selection){
 const server=P.profile.server;let target=slot;if(target===null||target===undefined)target=server.party.slice(0,P.rules.partySize(server.userExp)).findIndex(n=>n===0);if(target<0){await P.notice(P.text('local_popupcostover'));return false;}
 const party=server.party.slice(0,P.rules.partySize(server.userExp));party.forEach((seq,i)=>{if(seq===mon.seq)party[i]=0;});party[target]=mon.seq;
 const cost=party.reduce((n,seq)=>{const m=server.monsters.find(x=>x.seq===seq);return n+(m?P.rules.stars(m.id):0);},0);if(cost>P.data.starCapacity[P.rules.userLevel(server.userExp)-1]){await P.notice(P.text('local_popupcostover'));return false;}
 const result=P.request('/party_setting',{party_list:party});if(!result.ok){await P.notice(P.errorText(result.error));return false;}
 if(selection)P.closePanel(selection);const inventory=P.modal;if(inventory?.nativeClass==='CCBInventory')P.closePanel(inventory);await P.refreshDeck();
 const tutorial=P.profile.client.tutorial;
 if(tutorial===3){P.profile.client.tutorial=4;P.save();P.stage.mode=10;await P.talk(P.stage.host,2,11);}
 else if(tutorial===7){P.profile.client.tutorial=8;P.save();await P.handleTutorialMessage('Tutorial_Gotcha02');}
 else if(tutorial===9){P.profile.client.tutorial=10;P.save();P.stage.mode=0;P.stageActions();}
 else{P.stage.mode=0;P.stageActions();}return true;
};
P.beginPartyPosition=async function(mon,selection,inventory){if(inventory?.nativeSlot!==null&&inventory?.nativeSlot!==undefined)return P.placeMonster(mon,inventory.nativeSlot,selection);P.closePanel(selection);if(inventory)P.closePanel(inventory);P.stage.pendingPosition=mon.seq;P.stage.mode=5;P.actions(Array.from({length:P.rules.partySize(P.profile.server.userExp)},(_,i)=>({label:'Поставить в позицию '+(i+1),run:()=>P.commitPartyPosition(i)})));P.status('Выберите позицию в отряде',P.monsterName(mon.id));};
P.commitPartyPosition=async function(index){const mon=P.profile.server.monsters.find(m=>m.seq===P.stage.pendingPosition);if(mon&&await P.placeMonster(mon,index))P.stage.pendingPosition=null;};
P.openPartySlot=async function(index){const party=P.profile.server.party,seq=party[index];if(seq){const mon=P.profile.server.monsters.find(m=>m.seq===seq);await P.openPlacedCard(mon,index);}else await P.openInventory(index);};
P.openPlacedCard=async function(mon,index){const root=await P.panel('ccb/card_stage_info.ccbi');root.nativeSelection={mon,index};const card=await P.monsterCard(mon);card.setPosition(-120,112);root.addChild(card);const level=P.rules.monsterLevel(mon.id,mon.exp),prior=level>1?P.rules.threshold(mon.id,level-1):0;root.m_lblExp.setString(level>=P.rules.maxLevel(mon.id)?'0/0':'('+(mon.exp-prior)+'/'+(P.rules.threshold(mon.id,level)-prior)+')');await P.displayCardSkill(root,mon);P.menuActions(root,{1:'Убрать из отряда',2:'Усилить',3:'Закрыть',4:'Изменить позицию'});P.status('Карта монстра',P.monsterName(mon.id));return root;};
P.errorText=function(error){const keys={'Not enough gold':'local_popupnotenoughmoney','Not enough gem':'local_popupnotenoughgem','Not enough currency':'local_popupnotenoughgem','Monster box is full':'local_popupinvenisfull','Cannot sell this monster':'local_popupusingmonster'};return keys[error]?P.text(keys[error]):error;};
P.controllers.set('CCBInventory',{onMenuCallback:async function(sender){if(sender.getTag()===1)await P.closeInventory(this);else await P.notice(P.text('local_popupinvenisfull'));},onCardSelectCallback:async function(sender){const mon=P.profile.server.monsters.find(m=>m.seq===sender.getTag());if(mon)await P.inspectMonster(mon,this);}});
P.controllers.set('CCardSelect',{onCardSelectCallback:async function(sender){const {mon,inventoryRoot}=this.nativeSelection,tag=sender.getTag();if(tag===2)await P.beginPartyPosition(mon,this,inventoryRoot);else if(tag===3)P.closePanel(this);else if(tag===1&&!P.isPartyTutorial()){P.closePanel(this);await P.openEnhance(mon);}else if(tag===4&&!P.isPartyTutorial()){if(P.profile.server.party.includes(mon.seq))return P.notice(P.text('local_popupusingmonster'));await P.notice(P.text('local_popupasksell').replace('%d',String(P.rules.sellPrice(mon))),{confirm:true,yes:async()=>{const r=P.request('/mon_sell',{seq:mon.seq});if(!r.ok)return P.notice(P.errorText(r.error));P.closePanel(this);P.closePanel(inventoryRoot);await P.openInventory(inventoryRoot.nativeSlot);}});}}});
P.controllers.set('CCardSelectStage',{onCardSelectCallback:async function(sender){const {mon,index}=this.nativeSelection,tag=sender.getTag();if(tag===3)P.closePanel(this);else if(tag===1){const party=P.profile.server.party.slice(0,P.rules.partySize(P.profile.server.userExp));party[index]=0;const r=P.request('/party_setting',{party_list:party});if(!r.ok)return P.notice(P.errorText(r.error));P.closePanel(this);await P.refreshDeck();P.stageActions();}else if(tag===2){P.closePanel(this);await P.openEnhance(mon);}else if(tag===4){P.closePanel(this);await P.openInventory(index);}}});
})();
