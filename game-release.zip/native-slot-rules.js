/* SlotAnimationLayer::Roll 0x214cf0, getCharacterTheme 0x214b70.
 * These are the native cumulative probability tables, not prototype weights.
 * RNG distributions are preserved; the platform's random bitstream is not. */
(function(scope){
'use strict';
class NativeSlotRules{
 constructor(data,random=Math.random){this.data=data;this.config=data.nativeSlot;this.random=random;}
 int(n){return n<1?0:Math.floor(this.random()*n);}
 pick(bounds){const n=this.int(bounds[bounds.length-1]);for(let i=0;i<bounds.length-1;i++)if(bounds[i]<=n&&n<bounds[i+1])return i;return 0;}
 element(stage){return stage<1?0:this.pick(this.config.themeBounds[stage-1]);}
 frame(s){if(s.type===0)return `CD_UI_slot_hero_${s.element}${s.theme}.png`;if(s.type===1)return `CD_UI_slot_npc_${String(s.event-1).padStart(2,'0')}.png`;return `CD_UI_slot_money_${s.coin}.png`;}
 heroLevel(stage,userLevel,power){
  const capped=stage<16?Math.min(userLevel,stage*5-1):userLevel;
  const [min,max]=this.data.heroRanges[capped-1],range=max-min;
  let level=this.int(range)+min<99?this.int(range)+min:99;
  if(power===2)level=min+this.int(range)+this.int(range);
  else if(power===1)level=min+this.int(range)+Math.trunc(this.int(range)/2);
  return Math.min(99,level);
 }
 roll({stage,userLevel,gold,monsterCount,npcLevels=[]}){
  if(!Number.isInteger(stage)||stage<0||stage>16||!Number.isInteger(userLevel)||userLevel<1||userLevel>99)throw Error('Invalid native roulette stage/level');
  const c=this.config,p=this.int(100),power=stage<5?(p<30?1:p<50?2:0):0;
  const state={npc:false,coin:false,merchant:false},symbols=[],reels=[];
  for(let column=0;column<3;column++){
   const reel=[];
   for(let row=0;row<c.rows;row++){
    let s;
    if(row!==c.resultRow){
     const type=this.int(3);
     if(type===0)s={type,element:stage===0?[0,2,1][column]:this.element(stage),theme:stage===0?2:Math.floor((stage-1)/4)};
     else if(type===1)s={type,event:this.int(8)+1};
     else s={type,coin:c.coinValues[this.int(4)]};
    }else{
     let type=column===0?this.pick(c.typeBounds):state.npc?0:state.coin?2:this.pick([0,90,100]);
     if(stage===0)type=0;
     if(type===0){
      const element=stage===0?[0,2,1][column]:state.merchant&&stage>2?3:this.element(stage);
      s={type,element,theme:stage===0?1:Math.floor((stage-1)/4),level:stage===0?20:this.heroLevel(stage,userLevel,power),count:1};
      s.id=2000+element*100+s.theme;
     }else if(type===1){
      let event=c.npcIDs[this.pick(c.npcBounds)];
      if(event===5){if(gold>c.merchantGoldThreshold)state.merchant=true;else event=1;}
      else if(event===3&&monsterCount>99)event=2;
      const count=npcLevels[event]||0,level=event===1?Math.min(99,count+2):event===8?Math.min(99,count+5):0;
      s={type,event,level,id:3000+event};state.npc=true;
     }else{s={type,coin:c.coinValues[this.int(4)]};state.coin=true;}
     symbols.push(s);
    }
    reel.push({...s,frame:this.frame(s),x:c.columnX[column],y:row*c.rowStep-c.rowOffset-(s.type===1?c.npcRowOffset:0)});
   }
   reels.push(reel);
  }
  const coinSymbols=symbols.filter(s=>s.type===2),allSame=coinSymbols.length===3&&coinSymbols.every(s=>s.coin===coinSymbols[0].coin);
  return {symbols,reels,power,allSame,coins:coinSymbols.reduce((n,s)=>n+s.coin,0)*(allSame?10:1)};
 }
}
scope.NativeSlotRules=NativeSlotRules;
if(typeof module==='object'&&module.exports)module.exports={NativeSlotRules};
})(typeof window==='object'?window:globalThis);
