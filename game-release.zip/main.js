(function(){
'use strict';
const NativeApplication=cc.Application.extend({ctor:function(){this._super();cc.COCOS2D_DEBUG=0;cc.initDebugSetting();cc.setup('gameCanvas');cc.AppController.shareAppController().didFinishLaunchingWithOptions()},applicationDidFinishLaunching:function(){const view=cc.EGLView.getInstance();view.adjustViewPort(false);view.resizeWithBrowserSize(true);view.setDesignResolutionSize(960,640,cc.RESOLUTION_POLICY.SHOW_ALL);const d=cc.Director.getInstance();d.setDisplayStats(false);d.setAnimationInterval(1/60);NativePort.start().catch(NativePort.fail);return true}});
new NativeApplication();
})();
