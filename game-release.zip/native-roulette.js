/* Original CCBSlotMachine and SlotAnimationLayer display path.
 * Native addresses: 0x1f4c60, 0x2147c4, 0x1f52c0, 0x1f54b8, 0x1f4958. */
(function(){
'use strict';const P=window.NativePort;
const sprite=name=>cc.Sprite.createWithSpriteFrameName(name);
// Roulette theme order (0x1f52c0) differs from CObject's elemental enum.
const elements=['fire','water','leaf','light'],castleElements=elements;
P.prepareRoulette=function(){
 if(!P.rouletteAssets)P.rouletteAssets=Promise.all([
  ...Object.keys(P.frames).filter(n=>/^CD_UI_(slot_|x_)/.test(n)).map(P.preloadFrame),
  ...['CD_UI_slot_machine','CD_UI_slot_effect','CD_UI_slot_effect_01',...elements.map(e=>'CD_UI_slot_effect_'+e)].map(n=>P.preloadScene('ccb/'+n+'.ccbi'))
 ]);
 return P.rouletteAssets;
};
P.rectangleClip=function(width,height){
 const stencil=cc.DrawNode.create();
 stencil.drawPoly([cc.p(0,0),cc.p(width,0),cc.p(width,height),cc.p(0,height)],cc.c4f(1,1,1,1),0,cc.c4f(1,1,1,1));
 const clip=cc.ClippingNode.create(stencil);
 // Upstream Canvas clipping captures the viewport scale at construction.
 // Read it at draw time so rotating/resizing a phone does not move the mask.
 if(cc.renderContextType===cc.CANVAS)stencil.draw=function(ctx){
  const c=ctx||cc.renderContext,v=cc.EGLView.getInstance();
  c.beginPath();c.rect(0,-height*v.getScaleY(),width*v.getScaleX(),height*v.getScaleY());
 };
 return clip;
};
P.controllers.set('CCBSlotMachine',{
 loaded:function(){
  const c=P.data.nativeSlot,shade=cc.LayerColor.create(cc.c4b(0,0,0,100),960,640);
  shade.setPosition(-480,-320);this.addChild(shade,-100);
  const size=this.m_layerslot.getContentSize(),clip=P.rectangleClip(size.width,size.height),reels=cc.Layer.create();
  reels.setPosition(this.m_layerslot.getPositionX()*.5,this.m_layerslot.getPositionY()*.5);
  clip.addChild(reels);this.m_layerslot.addChild(clip);this.nativeReels=reels;
  this.nativeBorders=[];this.nativeEffects=[];this.nativeStopped=0;
  for(let i=0;i<12;i++){
   const order=c.borderSeq.slice((i%4)*4,(i%4)*4+4),frames=order.map(n=>cc.SpriteFrameCache.getInstance().getSpriteFrame('CD_UI_x_'+elements[n]+'.png'));
   const icon=cc.Sprite.createWithSpriteFrame(frames[0]);
   icon.setPosition(c.borderX[i%2],162-Math.floor(i/2)*65);
   icon.runAction(cc.RepeatForever.create(cc.Animate.create(cc.Animation.create(frames,c.borderSeconds))));
   this.addChild(icon,10,1750+i);this.nativeBorders.push(icon);
  }
 },
 onLeverCallback:function(){
  if(this.nativeBusy||P.stage.rollCount>=3)return;
  this.nativeBusy=true;this.nativePriorMode=P.stage.mode;P.stage.mode=3;P.stage.rollCount++;
  for(let tag=533;tag<536;tag++)this.getChildByTag(tag)?.removeFromParent(true);
  P.animateRoulette(this);
 }
});
P.roll=async function(){
 const s=P.stage;if(s.slotBusy||s.rollCount>=3||P.modal||![0,1].includes(s.mode))return;
 const cost=P.profile.server.party.reduce((n,seq)=>{const m=P.profile.server.monsters.find(m=>m.seq===seq);return n+(m?P.rules.stars(m.id):0);},0);
 if(s.index!==0&&cost===0)return P.popup(s.host,P.text('local_popupcostzero'));
 if(s.index!==0&&cost>P.data.starCapacity[P.rules.userLevel(P.profile.server.userExp)-1])return P.popup(s.host,P.text('local_popupcostover'));
 s.slotBusy=true;P.actions([]);P.status('Призыв героев');
 await P.prepareRoulette();
 s.slotPlan=new NativeSlotRules(P.data).roll({stage:s.index,userLevel:P.rules.userLevel(P.profile.server.userExp),gold:P.profile.server.gold,monsterCount:P.profile.server.monsters.length,npcLevels:P.profile.client.npcLevels});
 const root=await P.readScene('ccb/CD_UI_slot_machine.ccbi');root.setPosition(480,320);
 root.nativePlan=s.slotPlan;s.slot=root;s.host.addChild(root,105);P.modal=root;
 P.audio.play('spin_roll.mp3').catch(P.fail);
 P.controllers.get('CCBSlotMachine').onLeverCallback.call(root);
};
P.animateRoulette=function(root){
 const c=P.data.nativeSlot,easing=[cc.EaseElasticOut,cc.EaseExponentialOut,cc.EaseSineOut];
 for(const [column,reel]of root.nativePlan.reels.entries())for(const [row,entry]of reel.entries()){
  const icon=sprite(entry.frame);icon.setAnchorPoint(.5,0);icon.setPosition(entry.x,entry.y);root.nativeReels.addChild(icon);
  const move=easing[column].create(cc.MoveBy.create(c.durations[column],cc.p(0,c.travel)));
  if(row===c.resultRow)icon.runAction(cc.Sequence.create(move,cc.DelayTime.create(c.stopDelay),cc.CallFunc.create(()=>P.slotStopped(root,column).catch(P.fail))));
  else if(entry.y+c.travel>c.rowMax||entry.y+c.travel<c.rowMin)icon.runAction(cc.Sequence.create(move,cc.RemoveSelf.create(true)));
  else icon.runAction(move);
 }
};
P.slotStopped=async function(root,column){
 P.audio.play('spin_stop.mp3').catch(P.fail);
 const c=P.data.nativeSlot,symbol=root.nativePlan.symbols[column];
 const asset='ccb/CD_UI_slot_effect_'+(symbol.type===0?elements[symbol.element]:'01')+'.ccbi';
 const effect=await P.readScene(asset);effect.setPosition(column*124-c.effectXOffset,34.5);
 root.addChild(effect,0,533+column);root.nativeEffects[column]=effect;
 root.nativeStopped++;
 if(root.nativeStopped===3)for(let i=0;i<3;i++)P.after(root,c.numberDelay+i*c.numberStagger,()=>P.slotNumber(root,i).catch(P.fail));
};
P.slotNumber=async function(root,index){
 const c=P.data.nativeSlot,symbol=root.nativePlan.symbols[index],node=await P.readScene('ccb/CD_UI_slot_effect.ccbi');
 node.nativeSlotIndex=index;node.nativeSlotRoot=root;
 node.setPosition(index*124-c.effectXOffset,-128);
 const layer=node.m_layernumber;
 if(symbol.type===0||(symbol.type===1&&(symbol.event===1||symbol.event===8))){
  const names=['CD_UI_slot_level.png',...String(symbol.level).padStart(2,'0').split('').map(n=>'CD_UI_slot_number_'+n.padStart(2,'0')+'.png')];
  names.forEach((name,i)=>{const icon=sprite(name);icon.setAnchorPoint(0,0);icon.setPosition(c.numberX[i],c.numberY);layer.addChild(icon);});
 }else{
  const icon=sprite(symbol.type===1?'CD_UI_slot_event.png':'CD_UI_slot_machine_x'+(root.nativePlan.allSame?'10':'01')+'.png');
  icon.setPosition(0,0);layer.addChild(icon);
 }
 root.addChild(node,0,683+index);P.audio.play('spin_multiply.mp3').catch(P.fail);
 if(index===0)root.nativeBorders.forEach((border,i)=>P.after(border,.01+Math.floor(i/2)*.25,()=>P.slotAttribute(root,border)));
};
P.slotAttribute=function(root,border){
 if(!border.getParent())return;
 const group=P.stage.index<1?0:Math.floor((P.stage.index-1)/4),position=border.getPosition();
 const icon=sprite('CD_UI_x_'+castleElements[group]+'.png');icon.setPosition(position);root.addChild(icon);
 const glow=sprite('CD_UI_slot_light_'+['red','blue','green','yellow'][group]+'.png');
 glow.setPosition(position);glow.setBlendFunc(1,1);root.addChild(glow);
 glow.runAction(cc.Sequence.create(cc.FadeOut.create(P.data.nativeSlot.attributeFadeSeconds),cc.RemoveSelf.create(true)));
 border.removeFromParent(true);
};
P.controllers.set('CCBSlotNumberEffect',{
 completed:function(name){if(this.nativeSlotIndex===2&&name==='slot_effect_00'&&!this.nativeSlotRoot.nativeResultShown){this.nativeSlotRoot.nativeResultShown=true;P.slotRollResult(this.nativeSlotRoot);}}
});
P.slotRollResult=function(root){
 const flash=visible=>root.nativeEffects.forEach(n=>n.setVisible(visible)),wait=()=>cc.DelayTime.create(P.data.nativeSlot.flashSeconds);
 root.runAction(cc.Sequence.create(wait(),cc.CallFunc.create(()=>flash(true)),cc.DelayTime.create(.5),cc.CallFunc.create(()=>flash(false)),wait(),cc.CallFunc.create(()=>flash(true)),cc.DelayTime.create(.5),cc.CallFunc.create(()=>flash(false)),wait(),cc.CallFunc.create(()=>P.closeRoulette(root).catch(P.fail))));
};
P.closeRoulette=async function(root){
 const plan=root.nativePlan,s=P.stage;
 s.enterHeroes=plan.symbols.filter(n=>n.type!==2).map(n=>({...n}));
 if(plan.coins){const result=P.request('/spin_gold',{spin_gold:plan.coins});if(!result.ok)throw Error(result.error);}
 root.stopAllActions();root.removeFromParent(true);P.modal=null;s.slot=null;s.slotBusy=false;
 await P.notify('StageScene',plan.coins?'GetCoin':'ROff_1');
};
})();
