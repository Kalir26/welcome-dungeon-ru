/* StageScene / StageLayer widgets reconstructed from the original binary.
 * This module is internal until the entire native battle path is ported. */
(function(){
'use strict';const P=window.NativePort;
const sprite=name=>cc.Sprite.createWithSpriteFrameName(name);
P.tiledMap=async function(stage){const key='00_dungeon_'+String(stage).padStart(2,'0'),entry=P.mapIndex[key];if(!entry)throw Error('Native map not found: '+key);await Promise.all(entry.images.map(P.image));const response=await fetch('assets/'+entry.file);if(!response.ok)throw Error('Native map HTTP '+response.status);const xml=await response.text(),map=cc.TMXTiledMap.createWithXML(xml,'assets');if(!map)throw Error('Original Tiled map rejected: '+key);return map;};
P.walker=async function(type,delay){const names=[0,1,2,3].map(i=>type+'_walk_0'+i+'.png');await Promise.all(names.map(P.preloadFrame));const frames=names.map(n=>cc.SpriteFrameCache.getInstance().getSpriteFrame(n)),node=cc.Sprite.createWithSpriteFrame(frames[0]);node.setAnchorPoint(.5,0);node.runAction(cc.RepeatForever.create(cc.Animate.create(cc.Animation.create(frames,delay))));return node;};
P.spriteNumber=async function(value,prefix,gap=0){const names=String(value).split('').map(n=>prefix+'_'+String(Number(n)).padStart(2,'0')+'.png');await Promise.all(names.map(P.preloadFrame));const node=cc.Sprite.create();let x=0,height=0;for(const name of names){const digit=sprite(name);digit.setAnchorPoint(0,0);digit.setPosition(x,0);node.addChild(digit);x+=digit.getContentSize().width+gap;height=Math.max(height,digit.getContentSize().height);}return {node,width:Math.max(0,x-gap),height};};
P.cardDeck=async function(mon){
 const stage=P.data.nativeStage,more='CD_UI_encyclopedia_card_more.png';
 if(!mon){
  await Promise.all([more,'CD_UI_encyclopedia_card_line_silver.png'].map(P.preloadFrame));
  const node=await P.readScene('ccb/CardDeck.ccbi'),icon=sprite(more);
  // CCardDeck::onNodeLoaded, 0x1f879c. The plus is in the thumbnail area,
  // not centred on the complete 177px-tall card (which clips its lower half).
  icon.setPosition(55,124);
  const line=sprite('CD_UI_encyclopedia_card_line_silver.png');line.setAnchorPoint(0,0);
  node.m_layerThumbnail.addChild(icon);node.m_layerThumbnail.addChild(line);
  return node;
 }
 const c=P.rules.character(mon.id),grade=P.rules.stars(mon.id),color=grade===1?'blue':stage.cardColors[grade-1];
 const thumb='thumbnail_'+c.name+'.png',border='CD_UI_encyclopedia_card_line_'+color+'.png';
 const attribute='CD_UI_attribute_'+['fire','leaves','water','light'][c.element]+'.png';
 await Promise.all([thumb,border,attribute].map(P.preloadFrame));
 const node=await P.readScene('ccb/CardDeck.ccbi');node.nativeMonster=mon;
 const portrait=sprite(thumb);portrait.setPosition(...stage.cardThumbnail);
 const line=sprite(border);line.setAnchorPoint(0,0);
 const attr=sprite(attribute);attr.setPosition(...stage.cardAttribute);
 node.m_layerThumbnail.addChild(portrait);node.m_layerThumbnail.addChild(line);node.m_layerThumbnail.addChild(attr);
 const level=P.rules.monsterLevel(mon.id,mon.exp),server=P.profile.server,party=server.party.slice(0,P.rules.partySize(server.userExp)).map(seq=>server.monsters.find(m=>m.seq===seq)),boosts={},s=P.rules.teamStats(mon.id,level,party,mon.factionFlag||0,boosts);
 node.m_lblHP.setString((P.language==='ru'?'ЗД:':'HP:')+s.hp);
 node.m_lblAtk.setString((P.language==='ru'?'АТК:':'Atk:')+s.attack);
 node.m_lblDef.setString((P.language==='ru'?'ЗАЩ:':'Def:')+s.defence);
 for(const [field,key]of [['HP','hp'],['Atk','attack'],['Def','defence']])if(boosts[key])node['m_lbl'+field].setColor(cc.c3b(0,255,0));
 node.m_lblLv.setString('');
 const digits=await P.spriteNumber(String(level).padStart(2,'0'),'select_level');
 digits.node.setScale(stage.cardLevelScale);
 digits.node.setPosition(stage.cardLevelPosition[0]-digits.width*stage.cardLevelScale,stage.cardLevelPosition[1]);
 node.addChild(digits.node);
 return node;
};
P.stageDeck=async function(){const root=await P.readScene('ccb/stage_deck_ui.ccbi'),s=P.stage,profile=P.profile.server;root.m_layerForScroll.setOpacity(0);root.m_menuItemAuto.setVisible(false);root.m_menuItemSkip.setVisible(false);root.m_lblCost.setString(s.index===0?'0':String(profile.party.reduce((n,seq)=>{const m=profile.monsters.find(x=>x.seq===seq);return n+(m?P.rules.stars(m.id):0);},0)));root.m_lblMaxCost.setString(String(P.data.starCapacity[P.rules.userLevel(profile.userExp)-1]));const slots=s.index===0?6:P.rules.partySize(profile.userExp),cards=cc.Layer.create();cards.setContentSize(Math.max(695,slots*110),177);root.m_layerForScroll.addChild(cards);for(let i=0;i<slots;i++){const mon=s.index===0?{seq:i+1,id:P.data.nativeStage.sampleMonsters[i],exp:(i===0||i===3)?P.data.nativeStage.sampleExpA:P.data.nativeStage.sampleExpB}:profile.monsters.find(m=>m.seq===profile.party[i]);const card=await P.cardDeck(mon);card.setPosition(i*110,0);cards.addChild(card,0,400+i);}const trap=await P.readScene('ccb/CardTrap.ccbi');trap.m_lblAmount.setString('X'+Math.min(99,profile.traps));trap.m_sprUse.setVisible(false);trap.m_sprNotUse.setVisible(false);root.addChild(trap,0,500);s.cards=cards;return root;};
P.stageActions=function(){
 if(P.modal)return;
 if(P.stage.mode===0){P.status(P.stage.index===0?'Первое подземелье — потяните рычаг':'Подземелье '+P.stage.index);P.actions([{label:'Потянуть рычаг',run:()=>{
  const node=P.stage.lever;
  P.moveLever(node,-P.data.nativeLever.triggerTravel-1);
  P.resetLever(node);
 }},...(P.stageMenuActions?P.stageMenuActions():[])]);}else P.actions(P.stageMenuActions?P.stageMenuActions():[]);
};
P.controllers.set('StageDeckUI',{
 loaded:function(){this.setTouchMode(cc.TOUCH_ONE_BY_ONE);this.setTouchPriority(-129);this._swallowTouch=false;this.setTouchEnabled(true,false);},
 touchBegan:function(t){if(P.modal)return false;this.nativeTouch=t.getLocation();this.nativeMoved=false;return this.nativeTouch.y<177;},
 touchMoved:function(t){if(!this.nativeTouch)return;const p=t.getLocation(),dx=p.x-this.nativeTouch.x;this.nativeMoved=this.nativeMoved||Math.abs(dx)>5;const cards=P.stage.cards;cards.setPositionX(Math.max(Math.min(0,cards.getPositionX()+dx),Math.min(0,695-cards.getContentSize().width)));this.nativeTouch=p;},
 touchEnded:function(t){if(!this.nativeTouch)return;const moved=this.nativeMoved;this.nativeTouch=null;if(moved||P.modal)return;const s=P.stage,p=s.cards.convertToNodeSpace(t.getLocation()),i=Math.floor(p.x/110),slots=s.index===0?6:P.rules.partySize(P.profile.server.userExp);if(p.y<0||p.y>177||i<0||i>=slots)return;if(s.battle&&s.battle.mode===7)P.chooseBattleMonster(i);else if(s.mode===5)P.commitPartyPosition(i);else if(s.mode===0||P.isPartyTutorial?.())P.openPartySlot(i);},
 onAutoCallback:function(){},onSkipCallback:function(){if(P.stage.battle?.forfeit())P.processBattleEvents().catch(P.fail);}
});
P.showStage=async function(index,{transition=true}={}){
 P.actions([]);
 const host=cc.Layer.create(),s=P.stage={index,mode:10,host,room:-1,rollCount:0};
 const world=s.world=cc.Layer.create();world.setContentSize(0,0);host.addChild(world);
 const tiled=await P.tiledMap(index);world.addChild(tiled);s.tiled=tiled;
 const goal=tiled.getObjectGroup('Object').objectNamed('Goal'),portal=await P.readScene('ccb/portal.ccbi');
 portal.setPosition(Math.trunc(goal.x/64)*64+32,Math.trunc(goal.y/64)*64+16);tiled.addChild(portal,0,400);
 const ready=s.ready=await P.stageReady();host.addChild(ready,10,1);
 const deck=s.deck=await P.stageDeck();host.addChild(deck,105,6);
 const lever=s.lever=await P.readScene('ccb/stage_ui_lever_HD.ccbi');
 lever.setPosition(960,0);lever.setVisible(false);host.addChild(lever,105,2);
 if(index===0){const hand=await P.readScene('ccb/CD_UI_hand_cursor.ccbi');hand.setPosition(-50,100);lever.addChild(hand,100,240);}
 host.addChild(await P.hud(),100);
 P.notifications.set('StageScene',async message=>{
  if(message==='Tutorial_3')await P.talk(host,2,3);
  else if(message==='Tutorial_4'){s.mode=0;P.status('Первое подземелье — потяните рычаг');P.stageActions();}
  else if(message==='Roll')await P.roll();
  else if(message==='ROff_1'){
   s.mode=1;s.room=0;
   if(s.rollCount===1&&s.ready){s.mode=3;await P.readyComing(s.ready,s.enterHeroes);}
  }else if(message==='CommingEnd'){
   if(!P.startDungeon)throw Error('Перенос исходного первого боя ещё не завершён. Тестовый прогресс не изменён.');
   await P.startDungeon();
  }else if(message==='GetCoin'){
   s.mode=0;s.rollCount=0;s.enterHeroes=[];s.lever.m_sprBG.setVisible(true);s.lever.m_sprBG2.setVisible(false);P.stageActions();
  }else if(message==='CostOver'||message==='CostZero')await P.popup(host,P.text(message==='CostOver'?'local_popupcostover':'local_popupcostzero'));
  else if(!await P.handleBattleMessage?.(message)&&!await P.handleTutorialMessage?.(message))throw Error('StageScene notification not ported: '+message);
 });
 const scene=cc.Scene.create();scene.addChild(host);
 const director=cc.Director.getInstance();
 if(!director.getRunningScene())director.runWithScene(scene);
 else director.replaceScene(transition?cc.TransitionSlideInB.create(.5,scene):scene);
 P.currentRoot=host;P.currentAsset='stage:'+index;
 if(P.profile.client.tutorial<2)P.after(host,P.data.nativeStage.tutorialInitialDelay,()=>P.talk(host,2,2).catch(P.fail));
 else await P.initializeNormalStage();
};
})();
