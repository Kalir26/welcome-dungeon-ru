/* StageLeverUI, native 0x2179dc / 0x218510 / 0x2185a8 / 0x218a44.
 * m_sprKnob is the moving red handle; m_sprLever is the shaft behind it. */
(function(){
'use strict';const P=window.NativePort;
const active=()=>!P.modal&&P.stage.rollCount===0&&(P.stage.mode===0||(P.stage.index!==0&&P.stage.mode===1));
P.moveLever=function(node,delta){
 if(!active())return;
 const c=P.data.nativeLever,knob=node.m_sprKnob,shaft=node.m_sprLever;
 if(P.stage.index===0)node.getChildByTag(240)?.removeFromParent(true);
 const next=Math.fround(knob.getPositionY()+delta);
 if(next>=node.nativeKnobBase.y||next<=node.nativeKnobBase.y-c.travel)return;
 knob.setPositionY(next);
 let sound='';
 if(next>c.upperJoint){shaft.setPositionY(node.nativeShaftBase.y);shaft.setVisible(true);}
 else if(next>c.lowerJoint){
  shaft.setVisible(false);
  if(next===c.upperJoint)return;
  if(next>c.soundJoint){if(!node.nativePullSound)sound='spin_pull_1.mp3';}
  else if(node.nativePullSound==='spin_pull_1.mp3')sound='spin_pull_2.mp3';
 }else{
  shaft.setPositionY(node.nativeShaftBase.y-c.shaftDrop);shaft.setVisible(true);
  if(node.nativePullSound==='spin_pull_2.mp3')sound='spin_pull_3.mp3';
 }
 if(sound){node.nativePullSound=sound;P.audio.play(sound).catch(P.fail);}
};
P.resetLever=function(node){
 const c=P.data.nativeLever,knob=node.m_sprKnob,shaft=node.m_sprLever;
 const y=knob.getPositionY(),base=node.nativeKnobBase.y;
 node.nativePullSound='';
 node.m_sprBG.setVisible(true);node.m_sprBG2.setVisible(false);
 if(y<=base-c.triggerTravel&&active()){
  // The game-mode / party-cost checks belong to StageScene, as in the APK.
  P.notify('StageScene','Roll').catch(P.fail);
  node.m_sprBG.setVisible(false);node.m_sprBG2.setVisible(true);
 }
 const duration=(base-y)/c.returnDivisor*c.returnSeconds;
 const to=(target,dest,seconds)=>cc.MoveTo.create(Math.max(0,seconds),cc.p(target.getPositionX(),dest));
 if(y>c.upperJoint){
  knob.runAction(to(knob,base,duration));
 }else if(y>c.lowerJoint){
  const first=(c.upperJoint-y)/c.returnDivisor*c.returnSeconds;
  knob.runAction(cc.Sequence.create(to(knob,c.upperJoint,first),to(knob,base,(base-c.upperJoint)/c.returnDivisor*c.returnSeconds)));
  shaft.setOpacity(0);
  shaft.runAction(cc.Sequence.create(cc.DelayTime.create(first),to(shaft,node.nativeShaftBase.y,0),cc.FadeIn.create(0)));
 }else{
  const first=(c.lowerJoint-y)/c.returnDivisor*c.returnSeconds;
  knob.runAction(cc.Sequence.create(to(knob,c.lowerJoint,first),to(knob,c.upperJoint,0),to(knob,base,(base-c.upperJoint)/c.returnDivisor*c.returnSeconds)));
  shaft.setOpacity(255);
  shaft.runAction(cc.Sequence.create(cc.DelayTime.create(first),cc.FadeOut.create(0),cc.DelayTime.create(0),cc.Spawn.create(cc.FadeIn.create(0),to(shaft,node.nativeShaftBase.y,0))));
 }
 shaft.setVisible(true);
};
P.controllers.set('StageLeverUI',{
 loaded:function(){
  this.nativeKnobBase=this.m_sprKnob.getPosition();this.nativeShaftBase=this.m_sprLever.getPosition();
  this.nativePullSound='';this.nativeDragging=false;
  this.m_lblQuestDes.setFontName(P.text('local_font'));this.m_lblQuestDes.setFontSize(15);
  this.m_lblRegenTime.setVisible(false);this.m_lblSlotCount.setVisible(false);
  this.m_layerQuest.setVisible(P.stage.index!==0);
  // StageLeverUI::onNodeLoaded, 0x219498. Leave the room strip underneath.
  if(P.stage.index!==0)this.m_layerQuest.setPosition(0,30);
  this.setTouchMode(cc.TOUCH_ONE_BY_ONE);this.setTouchPriority(-129);this._swallowTouch=false;
  this.setTouchEnabled(true,false);this.scheduleUpdate();
 },
 update:function(){
  P.updateStageHUD?.();
  this.setVisible(active());
  if(P.reloadQuest&&!this.nativeQuestRefreshing&&(this.nativeQuestRevision!==(P.questRevision||0)||this.nativeQuestDay!==P.rules.localDay())){this.nativeQuestRefreshing=true;P.reloadQuest(this).catch(P.fail).finally(()=>{this.nativeQuestRefreshing=false;});}
  const knob=this.m_sprKnob,shaft=this.m_sprLever;
  if(knob.getPositionY()>this.nativeKnobBase.y)knob.setPositionY(this.nativeKnobBase.y);
  if(shaft.getPositionY()>this.nativeShaftBase.y)shaft.setPositionY(this.nativeShaftBase.y);
  const min=this.nativeKnobBase.y-P.data.nativeLever.clampTravel;
  if(knob.getPositionY()<min)knob.setPositionY(min);
 },
 touchBegan:function(t){
  if(!active())return false;
  const point=this.m_sprKnob.getParent().convertToNodeSpace(t.getLocation());
  this.nativeDragging=cc.rectContainsPoint(this.m_sprKnob.getBoundingBox(),point);
  this.nativePreviousY=t.getLocation().y;
  return true;
 },
 touchMoved:function(t){
  if(!this.nativeDragging||!active())return;
  const y=t.getLocation().y,delta=y-this.nativePreviousY;this.nativePreviousY=y;
  P.moveLever(this,delta);
 },
 touchEnded:function(){
  if(!this.nativeDragging)return;this.nativeDragging=false;
  if(P.stage.rollCount<3&&P.stage.mode!==3)P.resetLever(this);
 }
});
})();
