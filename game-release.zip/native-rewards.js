/* StageScene::addDailyEvent / addWheelEvent / showWheelButton,
 * native 0x21ce08 / 0x21cb20 / 0x21b008. Presentation only: the server
 * transaction already awarded these rewards, so no second award is possible. */
(function(){'use strict';const P=window.NativePort;
P.localImageName=function(base){return [base+'_'+P.language+'.png',base+'_en.png',base+'.png'].find(name=>P.resourcePaths[name])||base+'_en.png';};
P.rewardButton=async function(root,parent,x,y,normal,selected,label,closed){
 const a=await P.localSprite(normal),b=await P.localSprite(selected),menu=cc.Menu.create();menu.setPosition(0,0);menu.setTouchPriority(-2005);parent.addChild(menu,1);let busy=false;
 const button=cc.MenuItemSprite.create(a,b,()=>{if(busy||P.modal!==root)return;busy=true;P.audio.play('enchant_select.mp3');P.closePanel(root);Promise.resolve(closed?.()).catch(P.fail);});button.setPosition(x,y);button.nativeLabel=label;menu.addChild(button);P.menuActions(root);return button;
};
P.maybeDailyReward=async function(){
 const reward=P.profile.client.pendingDailyReward;if(!reward||P.modal||P.profile.client.tutorial<5)return;
 const title=P.localImageName('daily');await Promise.all(['daily_01.png','daily_02.png','daily_03.png',title].map(P.image));
 const root=await P.imagePanel('daily_01.png'),bg=root.nativeBackground,size=bg.getContentSize();root.nativeDailyReward=reward;
 const heading=cc.Sprite.create(title);heading.setPosition(size.width/2,size.height/2+210);bg.addChild(heading);
 for(let i=0;i<Math.min(reward.cycle,P.data.DAILY_REWARDS.length);i++){const mark=cc.Sprite.create(i===reward.cycle-1?'daily_02.png':'daily_03.png');mark.setPosition(76+i%5*121,379-Math.floor(i/5)*107);bg.addChild(mark);}
 await P.rewardButton(root,bg,size.width/2,size.height/2-195,'dungeon_button_00','dungeon_button_01','Получить ежедневную награду',()=>{delete P.profile.client.pendingDailyReward;P.save();});
 P.status('Ежедневный вход','День '+reward.cycle+'; '+(reward.type===2?'гемы: ':'ловушки: ')+reward.value);return root;
};
P.showWheelReward=async function(amount,closed){
 await Promise.all(['wheel_00.png','wheel_01.png','wheel_02.png','wheel_03.png'].map(P.image));
 const root=await P.imagePanel('wheel_03.png'),bg=root.nativeBackground,size=bg.getContentSize();root.nativeWheelAmount=amount;
 const title=cc.Sprite.create('wheel_00.png');title.setPosition(size.width/2,size.height/2+270);bg.addChild(title);
 const wheel=cc.Sprite.create('wheel_02.png');wheel.setPosition(size.width/2,size.height/2+30);bg.addChild(wheel);
 const pointer=cc.Sprite.create('wheel_01.png');pointer.setAnchorPoint(.5,.25);const ws=wheel.getContentSize();pointer.setPosition(ws.width/2,ws.height/2);wheel.addChild(pointer);
 const type=[1,2,3,5,10].indexOf(amount);if(type<0)throw Error('Unknown original wheel reward '+amount);
 const angle=type*72+36+1080,steps=Math.floor(angle/24),slow=(Math.floor(Math.random()*5)+3)*72;let elapsed=0,firstSlow=null,delay=.02;
 for(let i=0;i<steps;i++){if(i*24>angle-slow){firstSlow??=i;delay=.4*(i-firstSlow)/(steps-firstSlow)+.02;}pointer.runAction(cc.Sequence.create(cc.DelayTime.create(elapsed),cc.RotateBy.create(0,24)));elapsed+=delay;}
 P.status('Бонус за десять побед');P.actions([]);
 P.after(root,elapsed,()=>{(async()=>{const text=cc.LabelTTF.create(P.text('local_talkeventsystemgetgem').replace('%d',amount),P.text('local_font'),20);text.setAnchorPoint(.5,0);text.setPosition(size.width/2,size.height/2-210);bg.addChild(text);await P.rewardButton(root,bg,size.width/2,size.height/2-270,'CD_UI_popup_button_confirmation_00','CD_UI_popup_button_confirmation_01','Продолжить',closed);P.status('Бонус за десять побед','Гемы: '+amount);})().catch(P.fail);});return root;
};
})();
