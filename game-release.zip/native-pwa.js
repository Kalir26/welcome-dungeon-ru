/* Offline/PWA startup only. The native game and its save key stay unchanged. */
(function(){'use strict';const P=window.NativePort;
P.prepareOffline=async function(){
 if(location.pathname.startsWith('/__qa__/')||!('serviceWorker'in navigator)||!window.isSecureContext)return;
 const loading=document.getElementById('loading'),status=document.getElementById('offlineStatus');let first=!navigator.serviceWorker.controller;
 const progress=event=>{if(first&&event.data?.type==='W2D_CACHE_PROGRESS')loading.textContent='Сохраняем игру для работы без интернета: '+Math.floor(event.data.done/event.data.total*100)+'%';};
 navigator.serviceWorker.addEventListener('message',progress);
 const within=(promise,ms)=>new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Offline startup timed out; continuing online')),ms);promise.then(value=>{clearTimeout(timer);resolve(value);},error=>{clearTimeout(timer);reject(error);});});
 const waitState=worker=>new Promise((resolve,reject)=>{if(!worker||worker.state==='installed'||worker.state==='activated')return resolve();if(worker.state==='redundant')return reject(Error('Offline installation failed'));worker.addEventListener('statechange',()=>{if(worker.state==='installed'||worker.state==='activated')resolve();else if(worker.state==='redundant')reject(Error('Offline installation failed'));});});
 try{
  const registration=await within(navigator.serviceWorker.register('sw.js',{scope:'./',updateViaCache:'none'}),10000);
  // register() may return the old registration before its automatic update
  // check finishes. Finish this check at startup, so an already downloaded
  // replacement cannot leave this launch on stale controller code.
  if(registration.active)await within(registration.update(),10000);
  if(registration.installing)await within(waitState(registration.installing),45000);
  if(registration.waiting&&navigator.serviceWorker.controller){
   const changed=new Promise(resolve=>navigator.serviceWorker.addEventListener('controllerchange',resolve,{once:true}));
   const status=await within(new Promise(resolve=>{const done=event=>{if(['W2D_ACTIVATING','W2D_UPDATE_DEFERRED'].includes(event.data?.type)){navigator.serviceWorker.removeEventListener('message',done);resolve(event.data.type);}};navigator.serviceWorker.addEventListener('message',done);registration.waiting.postMessage({type:'W2D_ACTIVATE_AT_START'});}),10000);
   if(status==='W2D_ACTIVATING'){await within(changed,10000);location.reload();return new Promise(()=>{});}
  }
  if(first){await within(navigator.serviceWorker.ready,10000);if(!navigator.serviceWorker.controller)await within(new Promise(resolve=>navigator.serviceWorker.addEventListener('controllerchange',resolve,{once:true})),10000);}
  loading.textContent='Загрузка оригинальных сцен…';if(status)status.textContent='Автономная копия игры готова.';
 }catch(error){console.warn('Offline update check unavailable; continuing with the available build.',error);loading.textContent='Загрузка оригинальных сцен…';if(status)status.textContent=navigator.serviceWorker.controller?'Автономная копия игры готова.':'Автономная копия пока недоступна. Игра работает через интернет.';}
 finally{first=false;navigator.serviceWorker.removeEventListener('message',progress);}
};
})();
