/* Network stage-clear transaction and original battle/level-up CCBI panels. */
(function(){
'use strict';const P=window.NativePort;
P.nativeMenus=function(root){const out=[];function visit(n){if(n instanceof cc.Menu)out.push(n);for(const c of n.getChildren())visit(c);}visit(root);return out;};
P.menuActions=function(root,labels){const visible=b=>{for(let n=b;n;n=n.getParent()){if(!n.isVisible())return false;if(n===root)return true;}return false;};const buttons=P.nativeMenus(root).flatMap(m=>m.getChildren()).filter(b=>b instanceof cc.MenuItem&&visible(b));P.actions(buttons.map((b,i)=>({label:b.nativeLabel||labels?.[b.getTag()]||labels?.[i]||'Продолжить',disabled:!b.isEnabled(),run:()=>b.activate()})));};
P.panel=async function(asset,{position=[480,320],z,shade=200}={}){const previous=P.modal,node=await P.readScene(asset);node.setPosition(...position);if(shade){const bg=cc.LayerColor.create(cc.c4b(0,0,0,shade),960,640);bg.setPosition(-position[0],-position[1]);node.addChild(bg,-100);}P.rememberUI(node);node.previousModal=previous;(P.currentRoot||P.stage.host).addChild(node,z??(previous?previous.getZOrder()+1:200));P.modal=node;for(const m of P.nativeMenus(node))m.setTouchPriority(-2001-(previous?1:0));return node;};
P.closePanel=function(node){if(P.modal===node)P.modal=node.previousModal||null;node.removeFromParent(true);P.restoreUI(node);};
P.resultPortraits=async function(root,heroes){const rows=heroes.filter(h=>h.type===0).slice(0,3);for(const [i,h]of rows.entries()){const x=rows.length===1?0:rows.length===2?-100+i*200:-150+i*150,frame='CD_UI_slot_hero_'+h.element+h.theme+'.png',attribute='CD_UI_x_'+['fire','leaf','water','light'][h.element]+'.png';await Promise.all([frame,attribute].map(P.preloadFrame));const image=cc.Sprite.createWithSpriteFrameName(frame);image.setAnchorPoint(.5,0);image.setPosition(x,rows.length===1?0:40);root.addChild(image);const level=cc.LabelTTF.create((P.language==='ru'?'Ур.':'Lv.')+String(h.level).padStart(2,'0'),P.text('local_font'),15);level.setPosition(x,20);root.addChild(level);const icon=cc.Sprite.createWithSpriteFrameName(attribute);icon.setScale(.5);icon.setPosition(x-55,20);root.addChild(icon);}};
P.resultWheelProgress=async function(root){await Promise.all(['result_01.png','result_02.png','result_03.png'].map(P.image));const bg=cc.Sprite.create('result_01.png');bg.setPosition(0,220);root.addChild(bg);for(let i=0;i<P.profile.server.gemBonusCount;i++){const tick=cc.Sprite.create('result_02.png');tick.setPosition(35+i*61,13);bg.addChild(tick);}const marker=cc.Sprite.create('result_03.png');marker.setPosition(620,40);bg.addChild(marker);marker.runAction(cc.RepeatForever.create(cc.Blink.create(.5,1)));};
P.finishBattle=async function(win){
 const s=P.stage;if(s.result)return;s.mode=s.battle.mode=16;s.result={win,pending:true};P.actions([]);
 const oldLevel=P.rules.userLevel(P.profile.server.userExp),oldFrontier=P.rules.frontier(P.profile.server.userExp);
 // v98's rotating encounter quests use NPC symbols10..17. Hero element/theme
 // codes overlap those symbols, so they must not masquerade as NPC meetings.
 const spins=s.enterHeroes.map(h=>h.type===1?h.event+9:0);
 const response=P.request('/stage_clear',{stage:s.index,clear_yn:win?1:0,earn_orb:Math.min(3,s.battle.kills),use_trap:s.index===0?0:s.battle.usedTraps.size,spin_1:spins[0]||0,spin_2:spins[1]||0,spin_3:spins[2]||0,event:s.battle.eventResult||0});
 if(!response.ok){s.result=null;throw Error(response.error);}
 s.result={win,reward:response.reward,oldLevel,oldFrontier};
 if(win&&s.index===0){P.profile.client.tutorial=Math.max(2,P.profile.client.tutorial);P.save();}
 const root=await P.panel('ccb/CD_UI_battle_result_'+(win?'win':'lose')+'.ccbi');root.nativeResult=s.result;
 const labels={m_lblGetMoney:'local_uibattleresultgetmoney',m_lblGetExp:win?'local_uibattleresultgetexpwin':'local_uibattleresultgetexplose',m_lblGetMobExp:'local_uibattleresultgetmobexp',m_lblGetBonusMoney:'local_uibattleresultgetlevelbonus'};
 // CCBBattleResult::setFontByLanguage uses17px captions and15px talk for
 // the western/Russian fonts.20px wraps the40px captions into three lines.
 for(const [name,key]of Object.entries(labels))if(root[name]){root[name].setString(P.text(key));root[name].setFontName(['m_lblGetMoney','m_lblGetExp'].includes(name)?P.text('local_fontBold'):'font/BMHANNA.ttf');root[name].setFontSize(17);}
 const r=response.reward;for(const [name,value]of Object.entries({m_lblGold:r.gold+r.eventGold,m_lblBonus:r.userExp,m_lblMobExp:r.monsterExp,m_lblBonusGold:0}))root[name]?.setString(String(value));
 root.m_lblTalk.setString(P.text('local_minitalk'+(win?'die':'lost')+String(Math.floor(Math.random()*14)+1).padStart(2,'0')));root.m_lblTalk.setFontName(P.text('local_fontBold'));root.m_lblTalk.setFontSize(15);
 if(win){await P.resultPortraits(root,s.enterHeroes);await P.resultWheelProgress(root);}else{const eye=await P.readScene('ccb/CD_UI_result_cyclops.ccbi');eye.setPosition(70,69);root.addChild(eye);}
 // Only the win CCBI assigns m_menu; the lose CCBI's confirmation menu is
 // already visible and deliberately has no member assignment.
 root.m_menu?.setVisible(true);P.audio.stopMusic();P.audio.play(win?'result_won.mp3':'result_lose.mp3').catch(P.fail);
 P.menuActions(root,['Продолжить']);P.status(win?'Подземелье защищено':'Герои прорвали оборону',`Золото: ${r.gold+r.eventGold}; слава: ${r.userExp}; опыт монстров: ${r.monsterExp}`);
};
P.controllers.set('CCBBattleResult',{onResultCloseCallback:async function(){P.closePanel(this);await P.afterBattleResult();}});
P.afterBattleResult=async function(){
 const s=P.stage,r=s.result,newLevel=P.rules.userLevel(P.profile.server.userExp);
 if(r.reward.wheelGem&&!r.wheelShown){r.wheelShown=true;await P.showWheelReward(r.reward.wheelGem,P.afterBattleResult);return;}
 if(newLevel>r.oldLevel)await P.showLevelEvent(0,async()=>{
  const finish=async()=>{if(P.rules.frontier(P.profile.server.userExp)>r.oldFrontier)await P.showLevelEvent(1,P.afterDungeonOpened);else await P.resetStage();};
  // Native LevelUpEventOff exposes a new episode at odd levels3..57,
  // before the possible dungeon-unlock event.
  if(newLevel>=3&&newLevel<59&&newLevel%2===1)await P.showLevelEvent(2,finish);else await finish();
 });else await P.resetStage();
};
P.showLevelEvent=async function(type,closed){
 const root=await P.panel('ccb/CD_UI_levelup_event'+(['','_dungeon','_episode'][type])+'.ccbi');root.nativeLevelEvent={type,closed};
 const episode=Math.floor((P.rules.userLevel(P.profile.server.userExp)-1)/2);
 root.m_lblDes.setString(P.text(type===0?'local_levelupeventlevel':type===1?'local_levelupeventdungeon':'local_episodetitle'+String(episode).padStart(2,'0')));root.m_lblDes.setFontName(P.text('local_font'));if(['en','ru'].includes(P.language))root.m_lblDes.setFontSize(root.m_lblDes.getFontSize()*4/5);
 root.m_lblLevel?.setString(String(P.rules.userLevel(P.profile.server.userExp)));root.m_lblBonus?.setString('5');
 if(type!==2)P.audio.play(type===0?'result_levelup.mp3':'result_dungeonopen.mp3').catch(P.fail);P.menuActions(root,type===2?['Продолжить','Посмотреть историю']:['Продолжить']);P.status(['Новый уровень дурной славы','Открыто новое подземелье','Открыта новая история'][type]);
};
P.controllers.set('CCBLevelUpEvent',{onCloseCallback:async function(){const fn=this.nativeLevelEvent.closed;P.closePanel(this);await fn();},onWatchCallback:async function(){const fn=this.nativeLevelEvent.closed,episode=Math.floor((P.rules.userLevel(P.profile.server.userExp)-1)/2);P.closePanel(this);await fn();await P.openStory(episode);}});
P.afterDungeonOpened=async function(){if(P.profile.client.tutorial===2)await P.talk(P.stage.host,2,6);else await P.showWorldMap();};
// BattleResultOff resets the current stage in place (native 0x21dd70), without
// repeating the world-map's full-screen SlideInB entrance over the old battle.
P.resetStage=async function(){await P.showStage(P.stage.index,{transition:false});};
})();
