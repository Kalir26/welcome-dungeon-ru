/* CObject::LoadTalk, CCBTalkUI::{readTalk,handleResult,onSelectCallback},
 * original NPC dialogue table and deferred stage-clear event protocol. */
(function(){
'use strict';const P=window.NativePort;
P.npcTalk=async function(actor,index){
 const client=P.profile.client,b=P.stage.battle;client.npcCounts??=Array(9).fill(0);client.npcResults??=Array(9).fill(0);client.npcLevels??=Array(9).fill(0);const event=actor.id-3000;
 if(index==='entry'){index=P.data.nativeBattle.npcEntryTalk[event-1];if(event===1&&client.npcCounts[event]>0)index=client.npcResults[event]===1?4:3;else if(event===8&&client.npcCounts[event]>0)index=21;else if(event===4&&client.npcCounts[event]>0)index=10;client.npcCounts[event]++;}
 b.mode=P.stage.mode=10;P.save();const root=await P.talk(P.stage.host,0,index,P.data.nativeBattle.npcTalkKeys[index]);root.nativeTalk.actor=actor;
 root.nativeTalk.closed=()=>{const t=root.nativeTalk,keep=[0,3,4,16,21].includes(t.index);if(!keep&&!actor.removed){actor.removed=true;b.emit('remove',{actor});}b.mode=P.stage.mode=1;P.battleActions();};
};
P.loadNpcTalk=async function(root,index){
 const old=root.nativeTalk,parsed=P.parseTalk(P.text(P.data.nativeBattle.npcTalkKeys[index]));await Promise.all(parsed.pages.filter(p=>p.speaker!=='blank').map(p=>P.preloadScene('ccb/CD_UI_talk_npc_'+p.speaker+'.ccbi')));root.nativeTalk={...parsed,type:old.type,index,page:0,speaker:old.speaker,busy:false,actor:old.actor,closed:old.closed};root.m_menu.setVisible(false);P.actions([{label:'Продолжить диалог',run:()=>P.nextTalk(root)}]);await P.nextTalk(root);
};
P.handleTalkCommand=async function(root){
 if(root.nativeTalk.adventure)return P.handleAdventureTalkCommand(root);
 const t=root.nativeTalk,b=P.stage.battle,client=P.profile.client,command=t.command;let message='';
 if(command==='deal monsters level up'||command==='deal gem'){
  t.choosing=true;root.m_menu.setVisible(true);root.m_menu.setTouchPriority(-2002);root.m_lblTalk.setString(P.text(command==='deal gem'?'local_talkeventsystemdealgem':'local_talkeventsystemdealmonsterlevelup'));P.menuActions(root,{1:'Отказаться',2:'Согласиться'});return true;
 }
 if(command==='monsters level up'||command==='monster levels up'){
  b.mobEnhance=true;if(t.index===13)b.eventResult=1005;message=P.text('local_talkeventsystemmonsterlevelup');
 }else if(command==='hero levels up'){
  b.heroEnhance=true;for(const a of b.actors.filter(a=>a.type===100&&a.id<3000&&b.alive(a))){a.attack=Math.trunc(a.attack*1.5);a.battleScale=1.5;P.stage.actorViews.get(a.uid)?.setScale(1.5);}message=P.text('local_talkeventsystemherolevelsup');
 }else if(command==='hero hp down'){
  b.heroGravity=20;for(const a of b.actors.filter(a=>a.type===100&&a.id<3000&&b.alive(a)))a.hp=Math.trunc(a.hp*.8);message=P.text('local_talkeventsystemherohpdown');
 }else if(command==='get succubus card'){b.eventResult=1006;message=P.text('local_talkeventsystemgetsuccubuscard');
 }else if(command==='get gold'||command==='lose gold'||command==='get gold2'){
  b.eventResult=command==='get gold'?1001:command==='get gold2'?1002:0;const amount=command==='get gold2'?1000+(P.rules.userLevel(P.profile.server.userExp)-1)*50:1000;message=P.text(command==='lose gold'?'local_talkeventsystemlosegold':'local_talkeventsystemgetgold').replace('%d',String(amount));if(command==='get gold'){client.npcLevels[1]++;client.npcResults[1]=0;}else if(command==='lose gold')client.npcResults[1]=1;
 }else if(command==='get gem'||command==='get gold3'){
  let gem=command==='get gem';if(Math.floor(Math.random()*100)<(gem?60:40))gem=!gem;b.eventResult=gem?1004:1003;message=P.text(gem?'local_talkeventsystemgetgem':'local_talkeventsystemgetgold').replace('%d',gem?'1':'500');client.npcLevels[8]++;client.npcResults[8]=0;
 }else return false;
 P.save();root.m_lblTalk.setString(message);P.status('Диалог',message);P.actions([{label:'Продолжить диалог',run:()=>P.nextTalk(root)}]);return true;
};
P.chooseNpcTalk=async function(root,tag){const t=root.nativeTalk;if(!t.choosing)return;t.choosing=false;let index=t.index+tag;
 if(t.command==='deal monsters level up'&&tag===2&&P.profile.server.gold<3000)return P.notice(P.text('local_popupnotenoughmoney'),{closed:()=>P.loadNpcTalk(root,t.index+1)});
 await P.loadNpcTalk(root,index);
};
P.controllers.get('CCBTalkUI').onSelectCallback=async function(sender){if(this.nativeTalk.adventure)await P.chooseAdventureTalk(this,sender.getTag());else await P.chooseNpcTalk(this,sender.getTag());};
})();
