/* Versioned, atomic offline copy of this build. Player saves are never touched. */
'use strict';
const REVISION='d96e26b3697c6344a382',CACHE='w2d-faithful-'+REVISION;
const base=new URL('./',self.location.href),absolute=p=>new URL(p,base).href;
async function gameWindows(){return(await self.clients.matchAll({type:'window',includeUncontrolled:true})).filter(client=>{try{const u=new URL(client.url);return u.origin===base.origin&&(u.pathname===base.pathname||u.pathname===new URL('index.html',base).pathname);}catch{return false;}});}
async function notify(message){for(const client of await gameWindows())client.postMessage(message);}
self.addEventListener('install',event=>event.waitUntil((async()=>{
 const response=await fetch(absolute('precache.json'),{cache:'no-store'});
 if(!response.ok)throw Error('Offline manifest unavailable');
 const manifest=await response.json();if(manifest.revision!==REVISION)throw Error('Offline build mismatch');
 const cache=await caches.open(CACHE);let next=0,done=0;
 try{
  async function worker(){while(next<manifest.files.length){const entry=manifest.files[next++],url=absolute(entry.path),r=await fetch(url,{cache:'reload'});if(!r.ok)throw Error('Offline asset unavailable: '+entry.path);const bytes=await r.clone().arrayBuffer(),digest=await crypto.subtle.digest('SHA-256',bytes),hash=Array.from(new Uint8Array(digest),n=>n.toString(16).padStart(2,'0')).join('');if(hash!==entry.sha256)throw Error('Offline asset integrity mismatch: '+entry.path);
   // Hosting canonicalises /index.html to /. A redirected cached response
   // cannot be returned to a navigation with redirect mode'manual'. Keep its
   // verified bytes/headers but remove the transport redirect marker.
   await cache.put(url,r.redirected?new Response(bytes,{status:r.status,statusText:r.statusText,headers:r.headers}):r);done++;if(done%20===0||done===manifest.files.length)await notify({type:'W2D_CACHE_PROGRESS',done,total:manifest.files.length});}}
  // Wait for every worker to settle before removing a failed partial cache.
  const results=await Promise.allSettled(Array.from({length:4},worker)),failure=results.find(r=>r.status==='rejected');if(failure)throw failure.reason;
  const shell=await cache.match(absolute('offline-shell.json'));if(!shell)throw Error('Verified offline app shell missing');const {html}=await shell.json();if(typeof html!=='string')throw Error('Invalid offline app shell');await cache.put(absolute('index.html'),new Response(html,{headers:{'Content-Type':'text/html; charset=utf-8'}}));
 }catch(error){await caches.delete(CACHE);await notify({type:'W2D_CACHE_FAILED',message:String(error.message||error)});throw error;}
 // No automatic skipWaiting: never replace a build in the middle of a game.
})()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{
 for(const name of await caches.keys())if(name.startsWith('w2d-faithful-')&&name!==CACHE)await caches.delete(name);
 await self.clients.claim();await notify({type:'W2D_CACHE_READY',revision:REVISION});
})()));
self.addEventListener('message',event=>{if(event.data?.type!=='W2D_ACTIVATE_AT_START')return;event.waitUntil((async()=>{
 // Count actual game windows, not a host-created about:blank security iframe.
 const clients=await gameWindows();
 if(clients.length<=1){event.source?.postMessage({type:'W2D_ACTIVATING'});await self.skipWaiting();}
 else event.source?.postMessage({type:'W2D_UPDATE_DEFERRED'});
})());});
self.addEventListener('fetch',event=>{
 const request=event.request,url=new URL(request.url);
 if(request.method!=='GET'||url.origin!==base.origin||!url.pathname.startsWith(base.pathname))return;
 if(url.pathname===new URL('sw.js',base).pathname||url.pathname===new URL('precache.json',base).pathname)return;
 event.respondWith((async()=>{const cache=await caches.open(CACHE),cached=await cache.match(request,{ignoreSearch:true});if(cached)return cached;if(request.mode==='navigate'){const index=await cache.match(absolute('index.html'));if(index)return index;}return fetch(request);})());
});
