/* CCBEnhance: original one-row material scroller, target (-328,-16),
 * ten-material selection, feed preview and original enchant CCBI tracks. */
(function(){
'use strict';const P=window.NativePort,sprite=n=>cc.Sprite.createWithSpriteFrameName(n);
P.openEnhance=async function(mon){
 const root=await P.panel('ccb/CD_UI_enhance.ccbi',{shade:0});root.nativeEnhance={seq:mon.seq,selected:new Set(),cards:new Map(),busy:false};
 for(const [name,key,size,width]of [['m_lblEnhanceDes','local_uienhancedes',25,600],['m_lblEquipDes','local_equipmonster',25,200]]){root[name].setString(P.text(key));root[name].setFontName(P.text('local_fontBold'));P.fitLabel(root[name],width,size);}
 await P.drawEnhance(root);return root;
};
P.enhanceActions=function(root){if(P.modal!==root||root.nativeEnhance.busy)return;const state=root.nativeEnhance,s=P.profile.server;P.actions(s.monsters.filter(m=>m.seq!==state.seq&&!s.party.includes(m.seq)).map(m=>({label:(state.selected.has(m.seq)?'Снять выбор: ':'Материал: ')+P.monsterName(m.id)+' — ур. '+P.rules.monsterLevel(m.id,m.exp),run:()=>P.toggleEnhance(root,m.seq)})).concat([{label:'Выполнить слияние',run:()=>P.performEnhance(root)},{label:'Закрыть усиление',run:()=>P.closeEnhance(root)}]));};
P.drawEnhance=async function(root){
 const state=root.nativeEnhance,server=P.profile.server,mon=server.monsters.find(m=>m.seq===state.seq);if(!mon)throw Error('Enhancement target is absent');
 P.money(root);state.target?.removeFromParent(true);const target=state.target=await P.monsterCard(mon);target.setPosition(-328,-16);root.addChild(target,1);
 root.m_layerForScroll.removeAllChildren(true);const clip=P.rectangleClip(656,276);root.m_layerForScroll.addChild(clip);
 const material=server.monsters.filter(m=>m.seq!==mon.seq&&!server.party.includes(m.seq)),content=state.content=cc.Layer.create();content.setContentSize(Math.max(656,material.length*230),276);clip.addChild(content);
 const menu=P.scrollMenu(root,root.m_layerForScroll,656,276);content.addChild(menu);
 await Promise.all(['CD_UI_inventory_card_red.png','CD_UI_enchant_check.png'].map(P.preloadFrame));state.cards.clear();
 for(const [i,m]of material.entries()){const blank=sprite('CD_UI_inventory_card_red.png'),button=cc.MenuItemSprite.create(blank,null,()=>{if(P.modal===root&&!root.nativeDragging)P.toggleEnhance(root,m.seq).catch(P.fail);});button.setPosition(i*230+120,140);button.setTag(m.seq);menu.addChild(button);const card=await P.monsterCard(m);card.setPosition(i*230+120,140);content.addChild(card);state.cards.set(m.seq,{i,card});}
 P.installHorizontalDrag(root,content,root.m_layerForScroll,656,276);await P.enhancePreview(root);P.enhanceActions(root);P.status('Усиление монстра',P.monsterName(mon.id));
};
P.toggleEnhance=async function(root,seq){const state=root.nativeEnhance;if(state.busy)return;if(state.selected.has(seq))state.selected.delete(seq);else if(state.selected.size<10)state.selected.add(seq);await P.audio.play('enchant_select.mp3');await P.enhancePreview(root);P.enhanceActions(root);};
P.enhancePreview=async function(root){
 const state=root.nativeEnhance,s=P.profile.server,mon=s.monsters.find(m=>m.seq===state.seq),oldLevel=P.rules.monsterLevel(mon.id,mon.exp),exp=[...state.selected].reduce((n,seq)=>n+P.rules.feedExp(s.monsters.find(m=>m.seq===seq)),0),nextExp=P.rules.limitedExp(mon.id,mon.exp+exp),level=P.rules.monsterLevel(mon.id,nextExp),old=P.rules.stats(mon.id,oldLevel),next=P.rules.stats(mon.id,level);
 for(const [part,key]of [['Lv','level'],['HP','hp'],['Atk','attack'],['Def','defence']]){root['m_lblOri'+part].setString(String(old[key]));root['m_lbl'+part].setString(String(next[key]));}
 root.m_lblSelect.setString(state.selected.size+'/10');root.m_lblPrice.setString(String(P.rules.enhancePrice(mon,state.selected.size)));const from=oldLevel===1?0:P.rules.threshold(mon.id,oldLevel-1),to=P.rules.threshold(mon.id,oldLevel);root.m_lblDisplayExp.setString('EXP('+Math.max(0,mon.exp-from)+'/'+Math.max(0,to-from)+')');
 for(const [seq,{i}]of state.cards){const tag=100000+seq;state.content.getChildByTag(tag)?.removeFromParent(true);if(state.selected.has(seq)){const check=sprite('CD_UI_enchant_check.png');check.setPosition(i*230+190,260);state.content.addChild(check,100,tag);}}
};
P.performEnhance=async function(root){
 const state=root.nativeEnhance;if(state.busy||!state.selected.size)return;const old=P.profile.server.monsters.find(m=>m.seq===state.seq),before=P.rules.monsterLevel(old.id,old.exp);if(before>=P.rules.maxLevel(old.id))return P.notice(P.text('local_popupnomoreenhance'));
 const consumed=[...state.selected].map(seq=>P.profile.server.monsters.find(m=>m.seq===seq));const r=P.request('/mon_feed',{seq:state.seq,feed_list:[...state.selected]});if(!r.ok)return P.notice(P.errorText(r.error));state.busy=true;P.actions([]);root.m_layerWillBeHidden.setVisible(false);root.m_layerForScroll.setVisible(false);
 const clip=P.rectangleClip(925,276);root.m_layerForEffect.addChild(clip);
 await Promise.all(consumed.map(async(m,i)=>{const card=await P.monsterCard(m);card.setPosition(395+i*230,140);clip.addChild(card);await new Promise(resolve=>card.runAction(cc.Sequence.create(cc.DelayTime.create(1),cc.MoveTo.create(1,cc.p(125,140)),cc.CallFunc.create(resolve))));}));
 const mon=P.profile.server.monsters.find(m=>m.seq===state.seq),up=P.rules.monsterLevel(mon.id,mon.exp)>before;const effect=await P.readScene('ccb/CD_UI_enchant.ccbi');effect.setPosition(-328,-16);root.addChild(effect,1000);effect.nativeAnimation.runAnimationsForSequenceNamed(up?'enchant_levelup':'enchant');await P.audio.play('enchant_select.mp3');await new Promise(resolve=>P.after(root,up?1.666667:.766667,resolve));effect.removeFromParent(true);clip.removeFromParent(true);
 // Rebuild the finished window atomically. Reusing the effect scene left the
 // newly replaced target card blank in the Canvas renderer; it also retained
 // a second drag delegate after every feed. The original layout/transaction
 // and completed enchant track remain the same.
 state.selected.clear();state.busy=false;P.closePanel(root);await P.openEnhance(mon);await P.refreshDeck();P.updateStageMoney();
};
P.closeEnhance=async function(root){if(root.nativeEnhance.busy)return;const previous=root.previousModal;P.closePanel(root);if(previous?.nativeClass==='CCBInventory'){const slot=previous.nativeSlot;P.closePanel(previous);await P.openInventory(slot);}else{await P.refreshDeck();P.stageActions();}};
P.controllers.set('CCBEnhance',{onMenuCallback:async function(sender){const tag=sender.getTag();if(tag===1)await P.performEnhance(this);else if(tag===2)await P.closeEnhance(this);else if(tag===3)await P.openShop();else if(tag===5)await P.notice(P.text('local_enhancehelp'));},onCardSelectCallback:async function(sender){await P.toggleEnhance(this,sender.getTag());}});
})();
