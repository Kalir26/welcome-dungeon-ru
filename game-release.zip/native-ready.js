/* StageReady idle and entrance, native 0x21a038 / 0x21a158 / 0x219ce4 / 0x219a94. */
(function(){
'use strict';const P=window.NativePort;
const sprite=name=>cc.Sprite.createWithSpriteFrameName(name);
P.stageReady=async function(){
 const c=P.data.nativeStage,s=P.stage;
 await Promise.all(['CD_UI_balloon_00.png','CD_UI_balloon_02.png',...Array.from({length:4},(_,i)=>'eye_0'+i+'.png')].map(P.preloadFrame));
 await P.image('Texturepacker/CD_UI_balloon_04.png');
 const root=await P.readScene('ccb/stage_ready_fire.ccbi');
 const element=['fire','water','tree','light'][s.index===0?0:Math.floor((s.index-1)/4)],background='Texturepacker/background_'+element+'.png';
 await P.image(background);const bg=cc.Sprite.create(background);bg.setAnchorPoint(0,1);root.addChild(bg);
 const count=Math.floor(Math.random()*4)+1;
 for(let i=0;i<count;i++){
  const type=c.walkers[s.index===0?0:Math.floor(Math.random()*s.index)],actor=await P.walker(type,c.walkerFrameSeconds);
  actor.setPosition(180+i*160,c.walkerY);root.addChild(actor);root.nativeActors.push(actor);
 }
 const frames=Array.from({length:4},(_,i)=>cc.SpriteFrameCache.getInstance().getSpriteFrame('eye_0'+i+'.png'));
 const eye=cc.Sprite.createWithSpriteFrame(frames[0]);eye.setPosition(c.eyeX,c.eyeY);
 eye.runAction(cc.RepeatForever.create(cc.Animate.create(cc.Animation.create(frames,c.eyeFrameSeconds))));root.addChild(eye);
 root.setPosition(0,640);
 return root;
};
P.controllers.set('StageReady',{
 loaded:function(){this.nativeActors=[];this.nativeMoveTime=0;this.nativeTalkTime=0;this.scheduleUpdate();},
 entered:function(){P.audio.play('Dungeon_WoldmapBGM_Loop.mp3',true,true).catch(P.fail);},
 exited:function(){this.unscheduleUpdate();P.audio.play('BGM_Dungeon.mp3',true,true).catch(P.fail);},
 update:function(dt){
  if(P.stage.mode===1||P.stage.mode===3)return;
  const c=P.data.nativeStage;
  this.nativeMoveTime+=dt;this.nativeTalkTime+=dt;
  if(this.nativeMoveTime>=c.moveInterval){this.nativeMoveTime=0;P.moveReadyActors(this);}
  if(this.nativeTalkTime>=c.talkInterval){this.nativeTalkTime=0;P.readyTalk(this);}
 }
});
P.moveReadyActors=function(root){
 const c=P.data.nativeStage,edge=960/c.moveEdgeDivisor;
 for(const actor of root.nativeActors){
  actor.stopActionByTag(123);
  let right;
  if(actor.getPositionX()<edge)right=true;
  else if(actor.getPositionX()>960-edge)right=false;
  else if(Math.floor(Math.random()*3)!==0)right=Math.floor(Math.random()*2)===0;
  if(right!==undefined){
   actor.setFlippedX(right);
   const action=cc.RepeatForever.create(cc.MoveBy.create(c.moveSeconds,cc.p(right?c.movePixels:-c.movePixels,0)));
   action.setTag(123);actor.runAction(action);
  }
 }
};
P.readyTalk=function(root){
 if(!root.nativeActors.length)return;
 const c=P.data.nativeStage,actor=root.nativeActors[Math.floor(Math.random()*root.nativeActors.length)];
 const balloon=sprite('CD_UI_balloon_00.png');balloon.setAnchorPoint(0,1);balloon.setPosition(0,c.talkY);actor.addChild(balloon,1000,604);
 const middle=cc.Sprite.create('Texturepacker/CD_UI_balloon_04.png'),right=sprite('CD_UI_balloon_02.png');
 middle.setAnchorPoint(0,1);right.setAnchorPoint(0,1);
 const size=balloon.getContentSize();middle.setPosition(size.width-1,size.height);balloon.addChild(right);balloon.addChild(middle);
 const text=cc.LabelTTF.create(P.text('local_readytalk'+String(Math.floor(Math.random()*67)+1).padStart(2,'0')),P.text('local_font'),c.talkFontSize);
 text.setColor(cc.c3b(0,0,0));text.setAnchorPoint(0,.5);
 text.setPosition(middle.getPositionX()-size.width*.5,size.height-middle.getContentSize().height*.5);balloon.addChild(text);
 middle.setScaleX((text.getContentSize().width+4)/middle.getContentSize().width);
 right.setPosition(size.width+middle.getBoundingBox().width-2,size.height);
 balloon.runAction(cc.Sequence.create(cc.DelayTime.create(c.talkSeconds),cc.RemoveSelf.create(true)));
};
P.readyComing=async function(root,heroes){
 const c=P.data.nativeStage;
 root.nativeActors.forEach(n=>n.removeFromParent(true));root.nativeActors=[];
 for(const [index,hero]of heroes.entries()){
  const type=hero.id>2999?String(hero.id):c.walkers[Math.floor((hero.id-2000)/100)*4+(hero.id-2000)%100];
  const frame=type+'_walk_00.png';await P.preloadFrame(frame);
  const actor=sprite(frame);actor.setAnchorPoint(.5,0);actor.setPosition(960+index*c.comingStep,c.walkerY);root.addChild(actor);
  actor.runAction(cc.Sequence.create(cc.MoveTo.create(2+index*c.comingStep*2/(960-c.comingTargetX),cc.p(c.comingTargetX,c.walkerY)),cc.FadeOut.create(.5),cc.RemoveSelf.create(true)));
 }
 P.status('Герои входят в подземелье');
 P.after(root,c.comingSeconds,()=>{root.stopAllActions();P.notify('StageScene','CommingEnd').catch(P.fail);});
};
})();
