/* Original MP3 assets. Audio is optional, as in native SimpleAudioEngine:
 * a platform codec failure must never stop a battle or corrupt its result. */
(function(){'use strict';const P=NativePort;
let context,music,musicGain,effectGain,trackToken=0;
const buffers=new Map(),media=new Set(),warnings=new Set();
const volume=isMusic=>(P.profile?.client[isMusic?'musicVolume':'effectsVolume']??5)/5;
function warn(name,error){if(warnings.has(name))return;warnings.add(name);console.warn('[Audio] '+name+': '+String(error?.message||error));}
function stopMusic(){if(!music)return;try{if(typeof music.stop==='function')music.stop();else music.pause();}catch(error){warn('stopMusic',error);}media.delete(music);music=null;}
async function buffer(name){
 if(!buffers.has(name))buffers.set(name,fetch('assets/audio/'+name).then(r=>{if(!r.ok)throw Error('HTTP '+r.status);return r.arrayBuffer();}).then(bytes=>context.decodeAudioData(bytes)).catch(error=>{warn(name,error);return null;}));
 return buffers.get(name);
}
P.audio={
 unlock:async function(){try{if(!context){context=new(window.AudioContext||window.webkitAudioContext)();musicGain=context.createGain();effectGain=context.createGain();musicGain.connect(context.destination);effectGain.connect(context.destination);P.audio.setVolume();}if(context.state==='suspended')await context.resume();}catch(error){if(!musicGain||!effectGain)context=null;warn('AudioContext',error);}},
 setVolume:function(){if(context){musicGain.gain.value=volume(true);effectGain.gain.value=volume(false);}for(const node of media)node.volume=volume(node.nativeMusic);},
 play:async function(name,loop=false,isMusic=false){
  if(!context)return;
  const token=isMusic?++trackToken:0,decoded=await buffer(name);
  if(isMusic&&token!==trackToken)return;
  if(decoded)try{
   const node=context.createBufferSource();node.buffer=decoded;node.loop=loop;node.connect(isMusic?musicGain:effectGain);if(isMusic){stopMusic();music=node;node.onended=()=>{if(music===node)music=null;};}node.start();return node;
  }catch(error){warn(name+' (WebAudio)',error);}
  // A WebView can reject a short legacy MP3 in decodeAudioData while the
  // platform media decoder can still play that exact original file.
  try{const node=new Audio('assets/audio/'+name);node.loop=loop;node.volume=volume(isMusic);node.nativeMusic=isMusic;media.add(node);node.onended=()=>{media.delete(node);if(music===node)music=null;};node.onerror=()=>{media.delete(node);warn(name+' (media)',node.error||'unsupported audio');};if(isMusic){stopMusic();music=node;}await node.play();return node;}catch(error){warn(name+' (media)',error);}
 },
 stopMusic:function(){trackToken++;stopMusic();}
};
document.addEventListener('visibilitychange',()=>{if(!context)return;if(document.hidden)context.suspend().catch(console.warn);else context.resume().catch(console.warn);});
// CCBReader prefixes timeline sounds with its scene directory (ccb/). In the
// extracted game they are original MP3s in assets/audio, just like the direct
// controller effects. Do not let the upstream engine fetch a 404 HTML page and
// then throw EncodingError each time a looping death animation plays a sound.
if(window.cc?.BuilderSoundEffect)cc.BuilderSoundEffect.prototype.update=function(){
 const name=String(this._file).replace(/\\/g,'/').split('/').pop();
 if(name)P.audio.play(name).catch(error=>warn(name,error));
};
})();
