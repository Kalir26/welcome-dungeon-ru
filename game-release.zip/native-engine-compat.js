/* Narrow compatibility fixes for the unmodified Cocos2d-html5 2.2.3 bundle. */
(function(){
'use strict';
// Upstream 2.2.3 silently discards a third-argument callback; it supports the
// same callback only in the four-argument (normal, selected, callback, target)
// overload. Native-created menus have no JS target object. Normalize just that
// otherwise unsupported form, leaving all upstream overloads untouched.
if(cc.MenuItemSprite){
    const create=cc.MenuItemSprite.create;
    cc.MenuItemSprite.create=function(normal,selected,callback){
        if(arguments.length===3&&typeof callback==='function')
            return create.call(this,normal,selected,callback,null);
        return create.apply(this,arguments);
    };
}
// SlideInL completes on the outgoing scene's action. That target is normally
// visited first by ActionManager. Its finish() resets the incoming position
// before the incoming MoveBy has received its last update. Stackable MoveBy
// interprets the reset as another movement and leaves the new scene displaced
// (a whole screen when the browser was throttled to one frame per second).
// Stop only that transition's incoming action before the normal atomic reset.
// Durations, easing, scene order, and all child animations remain unchanged.
cc.TransitionSlideInL.prototype.onEnter=function(){
    cc.TransitionScene.prototype.onEnter.call(this);
    this.initScenes();
    const incoming=this.easeActionWithAction(this.action());
    const outgoing=cc.Sequence.create(
        this.easeActionWithAction(this.action()),
        cc.CallFunc.create(function(){
            this._inScene.stopAction(incoming);
            this.finish();
        },this)
    );
    this._inScene.runAction(incoming);
    this._outScene.runAction(outgoing);
};
})();
