/* Native tile/duel state machine. Source: CHero::Walk, CObject::{ToWalk,
 * update,Attack,AttackEvent}, CAttackEvent::checkEvent, ObjectLayer::ActionObject.
 * Rendering consumes events; no substitute arena, turn UI or simulated rewards. */
(function(scope){
'use strict';
const DIR=[[0,-1],[0,1],[-1,0],[1,0]],OPPOSITE=[1,0,3,2];
const key=(x,y)=>x+','+y;
const floatBits=n=>{const b=new ArrayBuffer(4),v=new DataView(b);v.setInt32(0,n,true);return v.getFloat32(0,true);};
class NativeBattleRules{
 constructor(rules,layout,stage,party,random=Math.random){
  this.rules=rules;this.d=rules.d.nativeBattle;this.layout=layout;this.stage=stage;this.party=party;this.teamEffects=stage===0?[]:rules.teamEffects(party);this.eventID=0;
  this.random=random;this.tiles=new Set(layout.walkable.map(p=>key(...p)));this.actors=[];this.queue=[];
  this.duels=[];this.events=[];this.used=new Set();this.usedTraps=new Set();this.nextUID=1;
  this.room=0;this.mode=0;this.actionTime=0;this.kills=0;this.ended=false;this.skillLesson=false;
  this.trapCount=0;this.autoTrap=true;this.userLevel=1;this.objectiveLost=false;this.mobEnhance=false;this.heroEnhance=false;this.heroGravity=0;
  const pos=o=>({x:Math.trunc(Number(o.x)/64),y:Math.trunc((layout.height*64-Number(o.y)-Number(o.height||0))/64)});
  this.start=pos(layout.objects.find(o=>o.name==='Start'));this.goal=pos(layout.objects.find(o=>o.name==='Goal'));
  this.slots=[];this.next=[];this.traps=new Set();
  for(let i=1;;i++){const s=layout.objects.find(o=>o.name==='Slot_'+i);if(!s)break;this.slots.push(pos(s));if(s.type==='Trap')this.traps.add(i-1);const n=layout.objects.find(o=>o.name==='Next_'+i);this.next.push(n?pos(n):null);}
 }
 int(n){return Math.floor(this.random()*n);}
 emit(type,fields={}){this.events.push({type,...fields});}
 drain(){return this.events.splice(0);}
 alive(a){return a.state!==4&&a.hp>0&&!a.removed;}
 occupancy(x,y){return this.actors.some(a=>this.alive(a)&&a.x===x&&a.y===y);}
 at(type,x,y){return this.actors.find(a=>a.type===type&&this.alive(a)&&a.x===x&&a.y===y);}
 create(id,level,x,y,{hero=false,factionFlag=0,seq=0}={}){
  const row=this.rules.d.characterRows[id];if(!row)throw Error('Missing native actor '+id);
  const a={...this.rules.stats(id,level),uid:this.nextUID++,x,y,worldX:x*64+32,worldY:y*64+16,
   type:row[15],moveSeconds:floatBits(row[8]),state:0,direction:hero?0:2,ready:true,
   animation:null,moveTime:0,factionFlag,charge:0,armed:false,skill:0,poison:0,insight:false,seq};
  if(!hero)this.rules.applyTeamEffects(a,this.teamEffects,factionFlag);
  if(hero&&this.stage===0)a.hp=a.maxHP=a.element===2?this.d.tutorialWaterHP:this.d.tutorialOtherHP;
  if(!hero&&this.d.positionByID[id]===1){a.worldX=(x+1)*64;a.worldY=y*64+32;}
  if(hero&&id<3000&&this.heroEnhance){a.attack=Math.trunc(a.attack*1.5);a.battleScale=1.5;}
  if(hero&&id<3000&&this.heroGravity)a.hp=Math.trunc(a.hp*(1-this.heroGravity/100));
  if(!hero&&id<5000&&this.mobEnhance){a.attack=Math.trunc(a.attack*1.5);a.battleScale=this.d.positionByID[id]===0?2:1;}
  this.actors.push(a);this.emit('spawn',{actor:a});
  if(!hero&&id<5000)this.animate(a,'SUMMON',1,6);else this.animate(a,'IDLE',1,0);
  return a;
 }
 animate(a,kind,speed=1,state=a.state){
  const directions=['FRONT','BACK','LEFT','RIGHT'];let direction=a.direction;
  if(a.type>100&&direction===0)direction=2;
  const names=this.d.sequencesByID[a.id]||{},name=(kind==='SUMMON'||kind==='DIE'||kind==='LEVELUP')?kind:kind+'_'+directions[direction];
  if(!(name in names))throw Error('Original actor sequence missing: '+a.id+' '+name);
  a.state=state;a.animation={kind,name,time:0,duration:names[name]/speed,speed,loop:kind==='IDLE'||kind==='WALK'};
  this.emit('animate',{actor:a,name,speed});
 }
 enqueue(symbols){for(const s of symbols)for(let i=0;i<(s.count||1);i++)this.queue.push({...s});this.mode=1;}
 walk(a){
  if(a.moveSeconds===0)return false;if(a.state!==0)return true;
  const choices=DIR.map((d,i)=>i).filter(i=>i!==OPPOSITE[a.direction]&&this.tiles.has(key(a.x+DIR[i][0],a.y+DIR[i][1])));
  if(!choices.length)return false;
  const direction=choices[this.int(choices.length)],[dx,dy]=DIR[direction],x=a.x+dx,y=a.y+dy;
  if(this.occupancy(x,y))return false;
  a.x=x;a.y=y;a.direction=direction;a.moveTime=0;this.animate(a,'WALK',1,1);return true;
 }
 attribute(a,b){if(a.element===b.element)return 0;if(a.element===3)return b.factionFlag===1?0:2;if(b.element===3)return a.factionFlag===1?0:1;return (a.element+1)%3===b.element?2:1;}
 duel(hero,mob){
  if(!this.alive(hero)||!this.alive(mob)||this.duels.some(d=>d.members.includes(hero)))return;
  let members=[hero,mob];const state=this.attribute(hero,mob);
  if(state===1||(state===0&&mob.factionFlag===1))members=[mob,hero];
  this.duels.push({members,turn:0,time:0});this.emit('duel',{members});
 }
 kill(a){
  if(a.state===4)return;a.hp=-9999;a.ready=false;
  this.duels=this.duels.filter(d=>!d.members.includes(a));
  if(a.type===100){this.kills++;this.emit('heroKilled',{actor:a});}
  if(a.id===3001||a.id===3008){a.state=4;a.animation=null;this.mode=10;this.emit('npcTalk',{actor:a,index:a.id===3001?1:17});}
  else if(a.id>=5000){this.objectiveLost=true;a.state=4;a.removed=true;this.emit('remove',{actor:a});}
  else this.animate(a,'DIE',1,4);
 }
 skillEffect(a,b){
  const skill=a.skill,grade=this.rules.stars(a.id)-1,n=a.level-1;
  a.armed=false;a.charge=0;a.chargeAnnounced=false;
  this.emit('skill',{actor:skill===1?a:b,skill});
  if(skill===2)b.poison=this.d.poisonBase[grade]+n*10;
  else if(skill===4)b.insight=true;
  else if(skill===5)b.attack=Math.trunc(b.attack*(1-Math.min(.800000011920929,this.d.attackReduction[grade]+n*.001)));
  else if(skill===6)b.defence=Math.trunc(b.defence*(1-Math.min(.800000011920929,this.d.defenceReduction[grade]+n*.003)));
  else if(skill===7){
   b.level=Math.max(1,Math.ceil(b.level-this.d.levelReduction[grade]-n*.1));
   const stats=this.rules.stats(b.id,b.level);b.attack=Math.min(b.attack,Math.max(1,stats.attack));b.defence=Math.min(b.defence,Math.max(1,stats.defence));b.maxHP=Math.min(b.maxHP,Math.max(1,stats.maxHP));b.hp=Math.max(1,Math.min(b.hp,b.maxHP));
  }
  return {critical:skill===0,heal:skill===1?this.d.healBase[grade]+n*50:skill===3?this.d.splashBase[grade]+n*30:0,leech:skill===3};
 }
 hit(a){
  const d=this.duels.find(x=>x.members.includes(a)),b=d?.members.find(x=>x!==a);
  if(!b||!this.alive(b)){a.ready=true;return;}
  let effect={critical:false,heal:0,leech:false},guaranteed=this.stage===0;
  if(a.type>100&&a.armed){effect=this.skillEffect(a,b);guaranteed=true;}
  let damage=this.rules.damage(a,b,a.insight||b.insight);
  if(!guaranteed&&[27,5,78,51,93].includes(this.int(100)))damage=0;
  if(effect.critical)damage*=2;
  if(effect.heal){a.hp=Math.min(a.maxHP,a.hp+effect.heal);this.emit('heal',{actor:a,value:effect.heal});if(effect.leech)damage+=effect.heal;}
  b.hp-=damage;this.emit('damage',{actor:b,attacker:a,value:damage,attribute:(a.insight||b.insight)?0:this.attribute(a,b)});
  if(a.type===100&&a.poison>0){a.hp-=a.poison;this.emit('damage',{actor:a,value:a.poison,attribute:0});if(a.hp<1){this.kill(a);b.ready=true;return;}}
  if(b.hp<1){this.kill(b);a.ready=true;this.emit('sound',{name:'mon_attack2.mp3'});return;}
  b.direction=b.type===100?3:2;
  if(b.state!==2)this.animate(b,'DAMAGE',1,3);
  if(b.type>100){
   if(this.stage===0){if(b.id===4020)b.charge=Math.min(100,b.charge+20);}
   else if(!b.armed){const disadvantage=this.attribute(a,b)===1;const trial=disadvantage?b.charge+this.int(30):b.charge+this.int(30)*1.2+10;b.charge=trial>(disadvantage?90:100)?100:Math.min(100,Math.trunc(b.charge+(disadvantage?this.int(30)+10:this.int(30)*1.2+10)));}
   if(this.stage===0&&b.charge===100&&!this.skillLesson){this.skillLesson=true;this.mode=11;this.emit('tutorialSkill',{actor:b});}
  }
  this.emit('sound',{name:'mon_attack1.mp3'});
 }
 armSkill(a){if(a.type<=100||!this.alive(a)||a.charge<100||a.armed)return false;a.armed=true;a.skill=this.d.skillByID[a.id];a.chargeAnnounced=false;this.mode=1;this.emit('skillArmed',{actor:a});return true;}
 summon(index){
  if(this.mode!==7||!this.party[index]||this.used.has(index))return false;
  if(this.stage===0&&this.room===0&&index!==1)return false;
  const mon=this.party[index],slot=this.slots[this.room];if(!slot)return false;
  this.used.add(index);this.create(mon.id,this.rules.monsterLevel(mon.id,mon.exp),slot.x,slot.y,{seq:mon.seq});
  this.room++;this.mode=1;this.emit('selected',{index});return true;
 }
 skip(){if(this.mode!==7||this.stage===0)return false;this.room++;this.mode=1;this.emit('skip');return true;}
 forfeit(){if(this.stage===0||this.mode!==1||!this.canForfeit||this.ended)return false;this.objectiveLost=true;this.queue=[];this.duels=[];for(const actor of this.actors){if(!actor.removed){actor.removed=true;this.emit('remove',{actor});}}return true;}
 reachedRoom(){if(this.mode!==1)return;this.mode=10;this.emit('room',{index:this.room,slot:this.slots[this.room]});}
 openRoom(){
  if(this.traps.has(this.room)){if(this.stage===0){this.mode=10;this.emit('tutorialTrap');}else if(this.autoTrap&&this.usedTraps.size<this.trapCount){this.mode=2;this.emit('activeTrap');}else{this.room++;this.mode=1;}return;}
  if(this.stage!==0&&this.room===this.slots.length-1){const slot=this.slots[this.room];this.create(5000+this.int(6),1,slot.x,slot.y);this.room++;this.mode=1;return;}
  if(this.stage!==0&&!this.party.some((m,i)=>m&&!this.used.has(i))){this.canForfeit=true;this.emit('canForfeit');this.room++;this.mode=1;return;}
  this.mode=7;this.emit('selectRoom',{index:this.room});
 }
 trapKind(){return this.stage===0?(this.room<4?0:1):(this.int(2)===0?this.int(8):8+this.int(2));}
 applyTrap(kind=this.trapKind()){
  if(kind<0||kind>9||!Number.isInteger(kind))throw Error('Invalid native trap kind');
  this.usedTraps.add(this.room);const slot=this.slots[this.room];
  const objects=this.actors.filter(a=>this.alive(a)).sort((a,b)=>a.uid-b.uid);let targets=[];
  if(kind<4)targets=objects.slice(0,kind%2===0?1:2);
  else if(kind===4)targets=objects.filter(a=>a.id>=2000&&a.id<=2099);
  else if(kind===5)targets=objects.filter(a=>a.id<2200||a.id>2299);
  else if(kind===6)targets=objects.filter(a=>a.id>=2100&&a.id<=2199);
  else if(kind===7)targets=objects.filter(a=>a.id!==2303);
  else{
   const grade=kind===8?1+this.int(4):5+this.int(2);
   const pool=this.rules.d.stars.flatMap((n,i)=>n===grade&&(i<83||i>94)?[4000+i]:[]);
   this.create(pool[this.int(pool.length)],this.userLevel,slot.x,slot.y);
  }
  for(const [i,a]of targets.entries()){if(i===0)this.emit('skill',{actor:a,skill:0});this.kill(a);}
  if(targets.length)this.emit('sound',{name:kind===0?'trap_bomb.mp3':'mon_attack2.mp3'});
  this.room++;this.mode=1;this.emit('trap',{kind});
 }
 update(dt){
  if(!Number.isFinite(dt)||dt<0)throw Error('Invalid battle time');if(this.ended)return;
  for(const a of [...this.actors]){
   if(a.state===1){a.moveTime+=dt;if(a.moveTime>a.moveSeconds){a.worldX=a.x*64+32;a.worldY=a.y*64+16;this.animate(a,'IDLE',1,0);a.moveTime=0;}else{const [dx,dy]=DIR[a.direction];a.worldX+=64*dt/a.moveSeconds*dx;a.worldY+=64*dt/a.moveSeconds*dy;}}
   const anim=a.animation;if(anim&&!anim.loop){anim.time+=dt;if(anim.time>anim.duration){a.animation=null;if(anim.kind==='ATTACK'){this.hit(a);if(this.alive(a)){a.ready=true;this.animate(a,'IDLE',1,0);}}else if(anim.kind==='DAMAGE'||anim.kind==='SUMMON'||anim.kind==='LEVELUP'){if(this.alive(a)){a.ready=true;this.animate(a,'IDLE',1,0);}}else if(anim.kind==='DIE'){a.removed=true;this.emit('remove',{actor:a});}}}
   if(a.type>100&&a.charge>=100&&!a.armed&&!a.chargeAnnounced&&this.alive(a)){a.chargeAnnounced=true;this.emit('charge',{actor:a});}
  }
  if(this.mode!==1)return;
  if(!this.queue.length&&!this.actors.some(a=>a.type===100&&!a.removed)){this.ended=true;this.mode=0;this.emit(this.objectiveLost?'lose':'win');return;}
  if(this.queue.length&&!this.occupancy(this.start.x,this.start.y)){
   const hero=this.queue.shift(),actor=this.create(hero.id,hero.level,this.start.x,this.start.y,{hero:true});if(hero.id>=3000&&hero.id<4000){this.mode=10;this.emit('npcTalk',{actor,index:'entry'});return;}
  }
  for(const d of [...this.duels]){d.time+=dt;if(d.time>this.d.duelInterval&&d.members.every(a=>a.ready&&this.alive(a))){const a=d.members[d.turn];d.members.forEach(b=>b.ready=false);a.direction=a.type===100?3:2;this.animate(a,'ATTACK',this.d.attackSpeed,2);d.turn=(d.turn+1)%d.members.length;d.time=0;}}
  this.actionTime+=dt;if(this.actionTime<=this.d.actionInterval)return;this.actionTime=0;
  for(const a of this.actors.filter(a=>a.type===100&&!a.removed)){
   if(!this.alive(a))continue;const next=this.next[this.room];
   if(next&&a.x===next.x&&a.y===next.y){this.reachedRoom();break;}
   if(!next&&a.x===this.goal.x&&a.y===this.goal.y){this.objectiveLost=true;a.removed=true;this.emit('remove',{actor:a});if(a.id===3001||a.id===3008){this.mode=10;this.emit('npcTalk',{actor:a,index:a.id===3001?2:20});}break;}
   if(!this.walk(a)){const m=this.at(101,a.x+1,a.y)||this.at(103,a.x+1,a.y);if(m){if(this.eventID!==6&&m.id>=5000&&(m.id<5003||m.id===5005)){if(this.int(10)!==0){m.removed=true;this.objectiveLost=true;this.emit('kidnap',{actor:a,target:m});this.emit('remove',{actor:m});}}else this.duel(a,m);}}
  }
 }
}
scope.NativeBattleRules=NativeBattleRules;if(typeof module==='object'&&module.exports)module.exports={NativeBattleRules,DIR,floatBits};
})(typeof window==='object'?window:globalThis);
