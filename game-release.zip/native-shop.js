/* ShopScene::init/initGemShop/initTrapShop (0x2134ac..0x2143a4).
 * The current APK builds this scene dynamically; CCBShopUI is obsolete.
 * The offline v98 DT_INAPP is empty. Never invent prices or award paid gems. */
(function(){
'use strict';const P=window.NativePort,sprite=n=>cc.Sprite.createWithSpriteFrameName(n);
P.imagePanel=async function(image){
 const previous=P.modal;await P.image(image);const root=cc.Layer.create();root.setContentSize(0,0);root.previousModal=previous;P.rememberUI(root);
 const bg=root.nativeBackground=cc.Sprite.create(image);bg.setPosition(480,320);root.addChild(bg);(P.currentRoot||P.stage.host).addChild(root,previous?previous.getZOrder()+1:200);P.modal=root;P.actions([]);return root;
};
P.freeGemsNotice=()=>P.notice(P.language==='ru'?'Рекламные задания недоступны в автономной версии. Гемы можно получить за игру, задания и ежедневный вход.':'Advertising offers are unavailable in this offline edition. Earn gems through play, quests and daily login.');
P.openShop=async function(){
 const frames=['CD_UI_inventory_small_close_button_00.png','CD_UI_inventory_small_close_button_01.png','CD_UI_shop_button_04.png','CD_UI_shop_button_05.png','CD_UI_shop_button_00.png','CD_UI_shop_button_01.png','CD_UI_shop_goblin_shop_title.png','CD_UI_shop_potion_shop_title.png','CD_UI_shop_bg.png','CD_UI_trab_card_back.png','CD_UI_shop_spin_bg.png',...Array.from({length:5},(_,i)=>'CD_UI_shop_zam_0'+i+'.png')];
 await Promise.all(frames.map(P.preloadFrame));await Promise.all(['CD_UI_shop_button_06.png','CD_UI_shop_button_07.png','shop_a.png'].map(P.image));
 const root=await P.imagePanel('Texturepacker/CD_UI_encyclopedia_window.png'),bg=root.nativeBackground,size=bg.getContentSize();root.nativeShop=true;
 const gem=root.nativeGemShop=cc.Layer.create(),trap=root.nativeTrapShop=cc.Layer.create();gem.setContentSize(0,0);trap.setContentSize(0,0);bg.addChild(gem);bg.addChild(trap);
 const menus=[];function menu(parent){const m=cc.Menu.create();m.setPosition(0,0);m.setTouchPriority(-2003);parent.addChild(m,1);menus.push(m);return m;}
 function button(m,normal,selected,x,y,tag,file=false){const a=file?cc.Sprite.create(normal):sprite(normal),b=selected?(file?cc.Sprite.create(selected):sprite(selected)):null,item=cc.MenuItemSprite.create(a,b,()=>{if(P.modal===root)P.shopButton(root,tag).catch(P.fail);});item.setTag(tag);item.setPosition(x,y);m.addChild(item);return item;}
 function text(parent,value,x,y,fontSize=18,width){const n=cc.LabelTTF.create(value,P.text('local_font'),fontSize);n.setPosition(x,y);if(width)P.fitLabel(n,width,fontSize);parent.addChild(n);return n;}
 const side=menu(bg);button(side,frames[0],frames[1],size.width-50,size.height-50,0);button(side,frames[2],frames[3],860,260,8);button(side,frames[4],frames[5],860,410,9);button(side,'CD_UI_shop_button_06.png','CD_UI_shop_button_07.png',860,110,7,true);
 const title=sprite('CD_UI_shop_goblin_shop_title.png');title.setPosition(210,565);gem.addChild(title);text(gem,P.text('local_uigemtitle'),size.width/2,575,40,420);const note=cc.Sprite.create('shop_a.png');note.setPosition(size.width/2,525);gem.addChild(note);
 const gm=menu(gem);for(let i=0;i<6;i++){const b=button(gm,'CD_UI_shop_bg.png',null,150+(i%3)*250,370-Math.floor(i/3)*230,i+1),sz=b.getContentSize(),icon=sprite('CD_UI_shop_zam_0'+Math.max(0,i-1)+'.png');icon.setPosition(sz.width/2,sz.height/2+(i<2?15:30));b.addChild(icon);text(b,P.language==='ru'?'Недоступно':'Unavailable',sz.width/2,sz.height/2-70,16,sz.width-15);}
 const trapTitle=sprite('CD_UI_shop_potion_shop_title.png');trapTitle.setPosition(210,565);trap.addChild(trapTitle);
 // Native western font sizes (0x213a28): title25, description15, both
 // centred inside500x150. The CCB/default40/25 sizes overlap in Russian.
 const western=['en','ru'].includes(P.language),titleText=cc.LabelTTF.create(P.text('local_uipotiontitle'),P.text('local_font'),western?25:40,cc.size(500,150),cc.TEXT_ALIGNMENT_CENTER,cc.VERTICAL_TEXT_ALIGNMENT_CENTER);titleText.setPosition(size.width/2,565);trap.addChild(titleText);
 const desc=cc.LabelTTF.create(P.text('local_uiPotiondes'),P.text('local_font'),western?15:25,cc.size(500,150),cc.TEXT_ALIGNMENT_CENTER,cc.VERTICAL_TEXT_ALIGNMENT_CENTER);desc.setPosition(size.width/2,460);trap.addChild(desc);
 const card=sprite('CD_UI_trab_card_back.png');card.setPosition(size.width/2-30,size.height/2-30);trap.addChild(card);text(card,'x5',card.getContentSize().width/2+170,card.getContentSize().height/2,30);
 const tm=menu(trap),buy=button(tm,'CD_UI_shop_spin_bg.png',null,size.width/2,80,10),bs=buy.getContentSize(),coin=sprite('CD_UI_shop_zam_00.png');coin.setPosition(bs.width/2-30,bs.height/2);buy.addChild(coin);text(buy,'x5',bs.width/2+30,bs.height/2,18);
 root.nativeShopMenus=menus;P.setShopTab(root,false);P.status('Магазин');return root;
};
P.setShopTab=function(root,trap){root.nativeTrapShop.setVisible(trap);root.nativeGemShop.setVisible(!trap);P.shopActions(root);};
P.shopActions=function(root){P.menuActions(root,{0:'Закрыть магазин',1:'Покупка гемов',2:'Покупка гемов',3:'Покупка гемов',4:'Покупка гемов',5:'Покупка гемов',6:'Покупка гемов',7:'Бесплатные гемы',8:'Лавка ловушек',9:'Магазин гемов',10:'Купить 5 ловушек за 5 гемов'});};
P.shopButton=async function(root,tag){
 if(root.nativeShopBusy)return;if(tag===0){P.closePanel(root);if(P.stage.gotcha)P.money(P.stage.gotcha);P.updateStageMoney();return;}
 if(tag===8||tag===9)return P.setShopTab(root,tag===8);if(tag===7)return P.freeGemsNotice();
 if(tag>=1&&tag<=6)return P.notice(P.language==='ru'?'Покупки за реальные деньги недоступны в автономной версии.':'Real-money purchases are unavailable in this offline edition.');
 if(tag!==10)return;root.nativeShopBusy=true;try{const r=P.request('/trap_buy');if(!r.ok)return P.notice(P.errorText(r.error));await P.refreshDeck();P.updateStageMoney();if(P.stage.gotcha)P.money(P.stage.gotcha);P.shopActions(root);P.audio.play('enchant_select.mp3').catch(P.fail);}finally{root.nativeShopBusy=false;}
};
})();
