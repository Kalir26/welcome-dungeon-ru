/* Native resource bridge. UI documents and animation tracks are not recreated:
 * the original CCBI v5 files are read by the upstream CocosBuilder reader. */
(function(){
'use strict';
const P=window.NativePort={build:'faithful-port-in-progress',language:'ru',issues:[],controllers:new Map(),sceneDocs:new Map(),sceneBytes:new Map(),images:new Map(),framesReady:new Set(),sceneJobs:new Map()};
const A='assets/';
P.fail=function(error){const message=String(error?.stack||error);P.issues.push(message);console.error(error);const box=document.getElementById('fatal');box.textContent='Перенос оригинальной игры ещё не завершён.\n'+String(error?.message||error);box.style.display='flex';document.getElementById('loading').style.display='none'};
window.addEventListener('error',e=>P.fail(e.error||e.message));
window.addEventListener('unhandledrejection',e=>P.fail(e.reason));
P.json=async function(path){const r=await fetch(A+path);if(!r.ok)throw Error(path+': HTTP '+r.status);return r.json()};
P.nativePath=function(path){return String(path).replace(/^.*?assets\//,'').replace(/^\.\//,'').replace(/\.ccb$/,'.ccbi')};
P.imagePath=function(path){path=P.nativePath(path);if(P.language==='ru')path=P.ruFiles?.[path]||path;return P.resourcePaths?.[path]||path};
P.image=function(path){path=P.imagePath(path);if(!P.images.has(path))P.images.set(path,new Promise((resolve,reject)=>{const im=new Image();im.onload=()=>{cc.TextureCache.getInstance().cacheImage(A+path,im);resolve(im)};im.onerror=()=>reject(Error('Original image missing: '+path));im.src=A+path}));return P.images.get(path)};
// The original episode CCBI names a selected frame absent from its plist.
// Native MenuItemImage tolerates a null selected image and keeps the normal
// artwork. Resolve only that known optional frame to the same original art.
P.frameAliases={'newepisode_watchnow_button_01.png':'newepisode_watchnow_button_00.png'};
P.frameName=function(name){name=P.frameAliases[name]||name;return P.language==='ru'?(P.ruFrames[name]||name):name;};
P.preloadFrame=async function(name){if(!name)return;name=P.frameName(name);if(P.framesReady.has(name))return;const f=P.frames[name];if(!f)throw Error('Original sprite frame missing: '+name);await P.image(f.atlas);if(P.framesReady.has(name))return;
 const [x,y,w,h]=f.rect,[sw,sh]=f.size,[tx,ty,tw,th]=f.trim;
 const offset=cc.p(tx+tw/2-sw/2,sh/2-ty-th/2);
 const texture=cc.TextureCache.getInstance().textureForKey(A+f.atlas);
 const sf=cc.SpriteFrame.createWithTexture(texture,cc.rect(x,y,w,h),!!f.rotated,offset,cc.size(sw,sh));
 // Match SpriteFrameCache::_addSpriteFramesWithDictionary's Canvas path.
 // The Canvas renderer does not unrotate a manually registered frame itself.
 if(cc.renderContextType===cc.CANVAS&&sf.isRotated()){const element=cc.cutRotateImageToCanvas(texture.getHtmlElementObj(),sf.getRectInPixels());const t=new cc.Texture2D();t.initWithElement(element);t.handleLoadedTexture();sf.setTexture(t);sf.setRect(cc.rect(0,0,w,h));}
 cc.SpriteFrameCache.getInstance().addSpriteFrame(sf,name);P.framesReady.add(name);
};
P.preloadScene=function(name){name=P.nativePath(name);if(!name.startsWith('ccb/'))name='ccb/'+name;if(P.sceneJobs.has(name))return P.sceneJobs.get(name);
 const job=(async()=>{const doc=await P.json(P.sceneIndex[name]);P.sceneDocs.set(name,doc);const r=await fetch(A+name);if(!r.ok)throw Error('Original CCBI missing: '+name);P.sceneBytes.set(name,new Uint8Array(await r.arrayBuffer()));const jobs=[];
 function walk(n){if(!P.library.getCCNodeLoader(n.kind))P.registerClass(n.kind);for(const [k,v]of Object.entries(n.props)){if(n.types[k]===10){if(v[0])jobs.push(P.preloadFrame(v[1]));else if(v[1])jobs.push(P.image(v[1]));}if(n.types[k]===11&&v)jobs.push(P.image(v));if(n.types[k]===23&&v)jobs.push(P.preloadScene(v));}
 for(const ps of Object.values(n.animations||{}))for(const [k,a]of Object.entries(ps))if(a.type===10)for(const key of a.keys){const [sheet,file]=key[3];if(sheet)jobs.push(P.preloadFrame(file));else if(file)jobs.push(P.image(file));}
 for(const c of n.children||[])walk(c)}walk(doc.root);await Promise.all(jobs);return doc})();P.sceneJobs.set(name,job);return job;
};
P.registerClass=function(kind){const base=(kind==='CHero'||kind==='CMob')?cc.Node:cc.Layer;
 const Klass=base.extend({
  ctor:function(){this._super();this.nativeClass=kind;this.outlets={};this.setContentSize(0,0);},
  onAssignCCBMemberVariable:function(target,name,node){target.outlets[name]=node;target[name]=node;return true;},
  onAssignCCBCustomProperty:function(target,name,value){(target.nativeProperties||(target.nativeProperties={}))[name]=value;return true;},
  onResolveCCBCCMenuItemSelector:function(target,name){return function(sender){
   if(P.modal){let ancestor=target;while(ancestor&&ancestor!==P.modal)ancestor=ancestor.getParent();if(!ancestor)return;}
   const controller=P.controllers.get(kind);
   if(!controller?.[name])return P.fail(Error('Native callback not ported: '+kind+'::'+name));
   const result=controller[name].call(target,sender);if(result?.catch)result.catch(P.fail);return result;
  };},
  onResolveCCBCCControlSelector:function(target,name){return this.onResolveCCBCCMenuItemSelector(target,name);},
  onNodeLoaded:function(){P.controllers.get(kind)?.loaded?.call(this);},
  onEnter:function(){base.prototype.onEnter.call(this);P.controllers.get(kind)?.entered?.call(this);},
  onExit:function(){base.prototype.onExit.call(this);P.controllers.get(kind)?.exited?.call(this);},
  onTouchBegan:function(t,e){try{return P.controllers.get(kind)?.touchBegan?.call(this,t,e)??false;}catch(error){P.fail(error);return true;}},
  onTouchMoved:function(t,e){P.controllers.get(kind)?.touchMoved?.call(this,t,e);},
  onTouchEnded:function(t,e){P.controllers.get(kind)?.touchEnded?.call(this,t,e);},
  onTouchCancelled:function(t,e){P.controllers.get(kind)?.touchEnded?.call(this,t,e);},
  update:function(dt){P.controllers.get(kind)?.update?.call(this,dt);}
 });
 P.library.registerCCNodeLoader(kind,new (cc.NodeLoader.extend({_createCCNode:function(){return new Klass()}}))());
 Klass.prototype.onResolveCCBCCCallFuncSelector=Klass.prototype.onResolveCCBCCMenuItemSelector;
};
P.readScene=async function(name,owner){await P.preloadScene(name);name=P.nativePath(name);if(!name.startsWith('ccb/'))name='ccb/'+name;const reader=new cc.BuilderReader(P.library);const root=reader.readNodeGraphFromData(P.sceneBytes.get(name),owner||null,cc.size(960,640));if(!root)throw Error('CCBI reader rejected '+name);root.nativeAnimation=reader.getAnimationManager();root.nativeAsset=name;const all=reader.getAnimationManagers();for(const n of all.allKeys()){n.nativeAnimation=all.objectForKey(n);n.nativeAnimation.setDelegate({completedAnimationSequenceNamed:function(sequence){const c=P.controllers.get(n.nativeClass);if(c?.completed)c.completed.call(n,sequence)}});}return root};
P.fontFamily=function(name,value=''){const names={'font/Press Start 2P.ttf':'PressStart','font/BMHANNA.ttf':'BMHANNA','font/NotoSans-Bold.ttf':'NotoSansGame','font/PixelMplus12-Regular.ttf':'PixelMplus','font/PixelMplus12-Bold.ttf':'PixelMplus'};const family=names[name]||name;return /[\u0400-\u04ff]/.test(String(value))&&['PixelMplus','BMHANNA'].includes(family)?'NotoSansGame':family;};
P.installFonts=function(){
 const ttf=cc.LabelTTF.prototype.setFontName;cc.LabelTTF.prototype.setFontName=function(name){return ttf.call(this,P.fontFamily(name,this.getString()));};
 // create/initWithString assigns _fontName directly, never calling the setter.
 // Normalize that path too or all dynamically built native screens use Times.
 const create=cc.LabelTTF.create;cc.LabelTTF.create=function(){const args=Array.from(arguments);if(args.length>1)args[1]=P.fontFamily(args[1],args[0]);return create.apply(this,args);};
 const text=cc.LabelTTF.prototype.setString;cc.LabelTTF.prototype.setString=function(value){value=String(value);const translated=P.language==='ru'?(P.ruLabels[value]??value):value;if(/[\u0400-\u04ff]/.test(translated)&&['PixelMplus','BMHANNA'].includes(this.getFontName()))ttf.call(this,'NotoSansGame');return text.call(this,translated);};
};
P.install=function(){P.library=cc.NodeLoaderLibrary.newDefaultCCNodeLoaderLibrary();const fu=cc.FileUtils.getInstance(),tc=cc.TextureCache.getInstance(),fc=cc.SpriteFrameCache.getInstance();
 const byteOriginal=fu.getByteArrayFromFile;fu.getByteArrayFromFile=function(path){const v=P.sceneBytes.get(P.nativePath(path));if(v)return v;throw Error('CCBI was not preloaded: '+path)};
 const addOriginal=tc.addImage;tc.addImage=function(path){const p=P.imagePath(path);const loaded=tc.textureForKey(A+p);if(loaded)return loaded;throw Error('Texture was not preloaded: '+path)};
 const frameOriginal=fc.getSpriteFrame;fc.getSpriteFrame=function(name){name=P.frameName(name);const f=frameOriginal.call(this,name);if(!f)throw Error('Sprite frame was not preloaded: '+name);return f};
 fc.addSpriteFrames=function(path){/* All frames are read from the original plist metadata by the deterministic exporter. */};
 P.installFonts();
};
P.initialize=async function(){[P.frames,P.sceneIndex,P.ruFrames,P.data,P.ruLabels,P.ruFiles,P.resourcePaths,P.mapIndex]=await Promise.all([P.json('frames.json'),P.json('scene_index.json'),P.json('frame_map_ru.json'),P.json('game_data.json'),P.json('label_map_ru.json'),P.json('file_map_ru.json'),P.json('resource_paths.json'),P.json('map_index.json')]);await Promise.all([document.fonts.load('20px PressStart'),document.fonts.load('20px NotoSansGame'),document.fonts.load('20px BMHANNA'),document.fonts.load('20px PixelMplus')]);P.install()};
})();
